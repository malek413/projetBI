// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package final_dw.dim_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: dim Purpose: extract<br>
 * Description: extract <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class dim implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "dim";
	private final String projectName = "FINAL_DW";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					dim.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(dim.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_4_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_5_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_6_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_7_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_8_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_9_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class agentStruct implements routines.system.IPersistableRow<agentStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_agent;

		public int getId_agent() {
			return this.id_agent;
		}

		public String agent_code;

		public String getAgent_code() {
			return this.agent_code;
		}

		public String company_code;

		public String getCompany_code() {
			return this.company_code;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_agent;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final agentStruct other = (agentStruct) obj;

			if (this.id_agent != other.id_agent)
				return false;

			return true;
		}

		public void copyDataTo(agentStruct other) {

			other.id_agent = this.id_agent;
			other.agent_code = this.agent_code;
			other.company_code = this.company_code;

		}

		public void copyKeysDataTo(agentStruct other) {

			other.id_agent = this.id_agent;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_agent = dis.readInt();

					this.agent_code = readString(dis);

					this.company_code = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_agent = dis.readInt();

					this.agent_code = readString(dis);

					this.company_code = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_agent);

				// String

				writeString(this.agent_code, dos);

				// String

				writeString(this.company_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_agent);

				// String

				writeString(this.agent_code, dos);

				// String

				writeString(this.company_code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_agent=" + String.valueOf(id_agent));
			sb.append(",agent_code=" + agent_code);
			sb.append(",company_code=" + company_code);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(agentStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_agent, other.id_agent);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				agentStruct agent = new agentStruct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "agent");
				}

				int tos_count_tDBOutput_1 = 0;

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				String tableName_tDBOutput_1 = "dim_agent";
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				long date_tDBOutput_1;

				java.sql.Connection conn_tDBOutput_1 = null;

				String properties_tDBOutput_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_1 == null || properties_tDBOutput_1.trim().length() == 0) {
					properties_tDBOutput_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_1.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_1 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_1.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_1 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_1 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_1;

				String driverClass_tDBOutput_1 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_1 = "root";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:zhHEgtlm0fTRBO42vR2d97ZkLFJTU3zL2tWAkQ==");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				java.lang.Class.forName(driverClass_tDBOutput_1);

				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				int count_tDBOutput_1 = 0;

				String insert_tDBOutput_1 = "INSERT INTO `" + "dim_agent"
						+ "` (`id_agent`,`agent_code`,`company_code`) VALUES (?,?,?)";
				int batchSize_tDBOutput_1 = 100;
				int batchSizeCounter_tDBOutput_1 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				agentStruct agent_tmp = new agentStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							row1.hotel = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 3;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 4;

							row1.arrival_date_month = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 5;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 6;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 7;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 8;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 9;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 10;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.children = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 11;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 12;

							row1.meal = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 13;

							row1.country = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 14;

							row1.market_segment = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 15;

							row1.distribution_channel = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 16;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 17;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 18;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 19;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 20;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 21;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 22;

							row1.deposit_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 23;

							row1.agent = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 24;

							row1.company = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 25;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 26;

							row1.customer_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 27;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}

							} else {

								row1.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 28;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 29;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 30;

							row1.reservation_status = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 31;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row1 = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								agent = null;

// # Output table : 'agent'
								agent_tmp.id_agent = 0;
								agent_tmp.agent_code = row1.agent;
								agent_tmp.company_code = row1.company;
								agent = agent_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "agent"
							if (agent != null) {

								/**
								 * [tDBOutput_1 main ] start
								 */

								currentComponent = "tDBOutput_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "agent"

									);
								}

								whetherReject_tDBOutput_1 = false;
								pstmt_tDBOutput_1.setInt(1, agent.id_agent);

								if (agent.agent_code == null) {
									pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(2, agent.agent_code);
								}

								if (agent.company_code == null) {
									pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(3, agent.company_code);
								}

								pstmt_tDBOutput_1.addBatch();
								nb_line_tDBOutput_1++;

								batchSizeCounter_tDBOutput_1++;
								if (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
									try {
										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
													: countEach_tDBOutput_1);
										}
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_1 = 0;
								}
								commitCounter_tDBOutput_1++;

								if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {

									try {
										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
													: countEach_tDBOutput_1);
										}
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_1 != 0) {
									}
									conn_tDBOutput_1.commit();
									if (rowsToCommitCount_tDBOutput_1 != 0) {
										rowsToCommitCount_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1 = 0;

								}

								tos_count_tDBOutput_1++;

								/**
								 * [tDBOutput_1 main ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_end ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_end ] stop
								 */

							} // End of branch "agent"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (batchSizeCounter_tDBOutput_1 != 0) {
						int countSum_tDBOutput_1 = 0;

						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_1 = 0;

				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

				}
				conn_tDBOutput_1.commit();
				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;

				conn_tDBOutput_1.close();

				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "agent");
				}

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class bookingStruct implements routines.system.IPersistableRow<bookingStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_status;

		public int getId_status() {
			return this.id_status;
		}

		public String booking_status;

		public String getBooking_status() {
			return this.booking_status;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_status;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final bookingStruct other = (bookingStruct) obj;

			if (this.id_status != other.id_status)
				return false;

			return true;
		}

		public void copyDataTo(bookingStruct other) {

			other.id_status = this.id_status;
			other.booking_status = this.booking_status;

		}

		public void copyKeysDataTo(bookingStruct other) {

			other.id_status = this.id_status;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_status = dis.readInt();

					this.booking_status = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_status = dis.readInt();

					this.booking_status = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_status);

				// String

				writeString(this.booking_status, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_status);

				// String

				writeString(this.booking_status, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_status=" + String.valueOf(id_status));
			sb.append(",booking_status=" + booking_status);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(bookingStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_status, other.id_status);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();
				bookingStruct booking = new bookingStruct();

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "booking");
				}

				int tos_count_tDBOutput_2 = 0;

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;

				String tableName_tDBOutput_2 = "dim_booking_statuts";
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
				calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
				calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
				long date_tDBOutput_2;

				java.sql.Connection conn_tDBOutput_2 = null;

				String properties_tDBOutput_2 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_2 == null || properties_tDBOutput_2.trim().length() == 0) {
					properties_tDBOutput_2 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_2.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_2 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_2.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_2 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_2 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_2;

				String driverClass_tDBOutput_2 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_2 = "root";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:CE590gBufbntG2QRYscGZfZBktn9Wlrev4ChOw==");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				java.lang.Class.forName(driverClass_tDBOutput_2);

				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				int count_tDBOutput_2 = 0;

				String insert_tDBOutput_2 = "INSERT INTO `" + "dim_booking_statuts"
						+ "` (`id_status`,`booking_status`) VALUES (?,?)";
				int batchSize_tDBOutput_2 = 100;
				int batchSizeCounter_tDBOutput_2 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tMap_2 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				bookingStruct booking_tmp = new bookingStruct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try {

					Object filename_tFileInputDelimited_2 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0 || random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_2, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_2 != null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();

						row2 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row2 = new row2Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_2 = 0;

							row2.hotel = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 1;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 2;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 3;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 4;

							row2.arrival_date_month = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 5;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 6;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 7;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 8;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 9;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 10;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.children = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 11;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 12;

							row2.meal = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 13;

							row2.country = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 14;

							row2.market_segment = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 15;

							row2.distribution_channel = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 16;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 17;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 18;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 19;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 20;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 21;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 22;

							row2.deposit_type = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 23;

							row2.agent = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 24;

							row2.company = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 25;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 26;

							row2.customer_type = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 27;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row2", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}

							} else {

								row2.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 28;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 29;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 30;

							row2.reservation_status = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 31;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row2.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row2", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row2.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							System.err.println(e.getMessage());
							row2 = null;

						}

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "row2"
						if (row2 != null) {

							/**
							 * [tMap_2 main ] start
							 */

							currentComponent = "tMap_2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row2"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_2 = false;
							boolean mainRowRejected_tMap_2 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
								// ###############################
								// # Output tables

								booking = null;

// # Output table : 'booking'
								booking_tmp.id_status = 0;
								booking_tmp.booking_status = row2.reservation_status;
								booking = booking_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_2 = false;

							tos_count_tMap_2++;

							/**
							 * [tMap_2 main ] stop
							 */

							/**
							 * [tMap_2 process_data_begin ] start
							 */

							currentComponent = "tMap_2";

							/**
							 * [tMap_2 process_data_begin ] stop
							 */
// Start of branch "booking"
							if (booking != null) {

								/**
								 * [tDBOutput_2 main ] start
								 */

								currentComponent = "tDBOutput_2";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "booking"

									);
								}

								whetherReject_tDBOutput_2 = false;
								pstmt_tDBOutput_2.setInt(1, booking.id_status);

								if (booking.booking_status == null) {
									pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(2, booking.booking_status);
								}

								pstmt_tDBOutput_2.addBatch();
								nb_line_tDBOutput_2++;

								batchSizeCounter_tDBOutput_2++;
								if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_2 = 0;
								}
								commitCounter_tDBOutput_2++;

								if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_2 != 0) {
									}
									conn_tDBOutput_2.commit();
									if (rowsToCommitCount_tDBOutput_2 != 0) {
										rowsToCommitCount_tDBOutput_2 = 0;
									}
									commitCounter_tDBOutput_2 = 0;

								}

								tos_count_tDBOutput_2++;

								/**
								 * [tDBOutput_2 main ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_end ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_end ] stop
								 */

							} // End of branch "booking"

							/**
							 * [tMap_2 process_data_end ] start
							 */

							currentComponent = "tMap_2";

							/**
							 * [tMap_2 process_data_end ] stop
							 */

						} // End of branch "row2"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (batchSizeCounter_tDBOutput_2 != 0) {
						int countSum_tDBOutput_2 = 0;

						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

						insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_2 = 0;

				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

				}
				conn_tDBOutput_2.commit();
				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;

				conn_tDBOutput_2.close();

				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "booking");
				}

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								ctn_tDBOutput_2.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public static class depositStruct implements routines.system.IPersistableRow<depositStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_deposit;

		public int getId_deposit() {
			return this.id_deposit;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_deposit;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final depositStruct other = (depositStruct) obj;

			if (this.id_deposit != other.id_deposit)
				return false;

			return true;
		}

		public void copyDataTo(depositStruct other) {

			other.id_deposit = this.id_deposit;
			other.deposit_type = this.deposit_type;

		}

		public void copyKeysDataTo(depositStruct other) {

			other.id_deposit = this.id_deposit;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_deposit = dis.readInt();

					this.deposit_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_deposit = dis.readInt();

					this.deposit_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_deposit);

				// String

				writeString(this.deposit_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_deposit);

				// String

				writeString(this.deposit_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_deposit=" + String.valueOf(id_deposit));
			sb.append(",deposit_type=" + deposit_type);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(depositStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_deposit, other.id_deposit);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();
				depositStruct deposit = new depositStruct();

				/**
				 * [tDBOutput_3 begin ] start
				 */

				ok_Hash.put("tDBOutput_3", false);
				start_Hash.put("tDBOutput_3", System.currentTimeMillis());

				currentComponent = "tDBOutput_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "deposit");
				}

				int tos_count_tDBOutput_3 = 0;

				int nb_line_tDBOutput_3 = 0;
				int nb_line_update_tDBOutput_3 = 0;
				int nb_line_inserted_tDBOutput_3 = 0;
				int nb_line_deleted_tDBOutput_3 = 0;
				int nb_line_rejected_tDBOutput_3 = 0;

				int deletedCount_tDBOutput_3 = 0;
				int updatedCount_tDBOutput_3 = 0;
				int insertedCount_tDBOutput_3 = 0;
				int rowsToCommitCount_tDBOutput_3 = 0;
				int rejectedCount_tDBOutput_3 = 0;

				String tableName_tDBOutput_3 = "dim_deposit";
				boolean whetherReject_tDBOutput_3 = false;

				java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
				calendar_tDBOutput_3.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
				calendar_tDBOutput_3.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
				long date_tDBOutput_3;

				java.sql.Connection conn_tDBOutput_3 = null;

				String properties_tDBOutput_3 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_3 == null || properties_tDBOutput_3.trim().length() == 0) {
					properties_tDBOutput_3 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_3.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_3 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_3.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_3 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_3 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_3;

				String driverClass_tDBOutput_3 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_3 = "root";

				final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:rupGsJnT8s+92NJJOTS23OubGbFd7IgfpcVLoA==");

				String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
				java.lang.Class.forName(driverClass_tDBOutput_3);

				conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3,
						dbPwd_tDBOutput_3);

				resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);
				conn_tDBOutput_3.setAutoCommit(false);
				int commitEvery_tDBOutput_3 = 10000;
				int commitCounter_tDBOutput_3 = 0;

				int count_tDBOutput_3 = 0;

				String insert_tDBOutput_3 = "INSERT INTO `" + "dim_deposit"
						+ "` (`id_deposit`,`deposit_type`) VALUES (?,?)";
				int batchSize_tDBOutput_3 = 100;
				int batchSizeCounter_tDBOutput_3 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);

				/**
				 * [tDBOutput_3 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tMap_3 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				depositStruct deposit_tmp = new depositStruct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_3 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_3", false);
				start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_3";

				int tos_count_tFileInputDelimited_3 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_3 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_3 = null;
				int limit_tFileInputDelimited_3 = -1;
				try {

					Object filename_tFileInputDelimited_3 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_3 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_3 = 0, random_value_tFileInputDelimited_3 = -1;
						if (footer_value_tFileInputDelimited_3 > 0 || random_value_tFileInputDelimited_3 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_3 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_3, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_3 != null && fid_tFileInputDelimited_3.nextRecord()) {
						rowstate_tFileInputDelimited_3.reset();

						row3 = null;

						boolean whetherReject_tFileInputDelimited_3 = false;
						row3 = new row3Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_3 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_3 = 0;

							row3.hotel = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 1;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 2;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 3;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 4;

							row3.arrival_date_month = fid_tFileInputDelimited_3
									.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 5;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 6;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 7;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 8;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 9;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 10;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.children = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 11;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 12;

							row3.meal = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 13;

							row3.country = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 14;

							row3.market_segment = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 15;

							row3.distribution_channel = fid_tFileInputDelimited_3
									.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 16;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 17;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 18;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 19;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 20;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 21;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 22;

							row3.deposit_type = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 23;

							row3.agent = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 24;

							row3.company = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 25;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 26;

							row3.customer_type = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 27;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row3", temp, ex_tFileInputDelimited_3), ex_tFileInputDelimited_3));
								}

							} else {

								row3.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 28;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 29;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 30;

							row3.reservation_status = fid_tFileInputDelimited_3
									.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 31;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									row3.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row3", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								row3.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_3.getException() != null) {
								throw rowstate_tFileInputDelimited_3.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_3 = true;

							System.err.println(e.getMessage());
							row3 = null;

						}

						/**
						 * [tFileInputDelimited_3 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_3 main ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						tos_count_tFileInputDelimited_3++;

						/**
						 * [tFileInputDelimited_3 main ] stop
						 */

						/**
						 * [tFileInputDelimited_3 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_begin ] stop
						 */
// Start of branch "row3"
						if (row3 != null) {

							/**
							 * [tMap_3 main ] start
							 */

							currentComponent = "tMap_3";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_3 = false;
							boolean mainRowRejected_tMap_3 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
								// ###############################
								// # Output tables

								deposit = null;

// # Output table : 'deposit'
								deposit_tmp.id_deposit = 0;
								deposit_tmp.deposit_type = row3.deposit_type;
								deposit = deposit_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_3 = false;

							tos_count_tMap_3++;

							/**
							 * [tMap_3 main ] stop
							 */

							/**
							 * [tMap_3 process_data_begin ] start
							 */

							currentComponent = "tMap_3";

							/**
							 * [tMap_3 process_data_begin ] stop
							 */
// Start of branch "deposit"
							if (deposit != null) {

								/**
								 * [tDBOutput_3 main ] start
								 */

								currentComponent = "tDBOutput_3";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "deposit"

									);
								}

								whetherReject_tDBOutput_3 = false;
								pstmt_tDBOutput_3.setInt(1, deposit.id_deposit);

								if (deposit.deposit_type == null) {
									pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_3.setString(2, deposit.deposit_type);
								}

								pstmt_tDBOutput_3.addBatch();
								nb_line_tDBOutput_3++;

								batchSizeCounter_tDBOutput_3++;
								if (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
									try {
										int countSum_tDBOutput_3 = 0;
										for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
											countSum_tDBOutput_3 += (countEach_tDBOutput_3 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
										insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_3 = 0;
										for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
											countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0
													: countEach_tDBOutput_3);
										}
										rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
										insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_3 = 0;
								}
								commitCounter_tDBOutput_3++;

								if (commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {

									try {
										int countSum_tDBOutput_3 = 0;
										for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
											countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
										insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_3 = 0;
										for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
											countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0
													: countEach_tDBOutput_3);
										}
										rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
										insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_3 != 0) {
									}
									conn_tDBOutput_3.commit();
									if (rowsToCommitCount_tDBOutput_3 != 0) {
										rowsToCommitCount_tDBOutput_3 = 0;
									}
									commitCounter_tDBOutput_3 = 0;

								}

								tos_count_tDBOutput_3++;

								/**
								 * [tDBOutput_3 main ] stop
								 */

								/**
								 * [tDBOutput_3 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_3";

								/**
								 * [tDBOutput_3 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_3 process_data_end ] start
								 */

								currentComponent = "tDBOutput_3";

								/**
								 * [tDBOutput_3 process_data_end ] stop
								 */

							} // End of branch "deposit"

							/**
							 * [tMap_3 process_data_end ] start
							 */

							currentComponent = "tMap_3";

							/**
							 * [tMap_3 process_data_end ] stop
							 */

						} // End of branch "row3"

						/**
						 * [tFileInputDelimited_3 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_3 end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_3 != null) {
							fid_tFileInputDelimited_3.close();
						}
					}
					if (fid_tFileInputDelimited_3 != null) {
						globalMap.put("tFileInputDelimited_3_NB_LINE", fid_tFileInputDelimited_3.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_3", true);
				end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_3 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tDBOutput_3 end ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					if (batchSizeCounter_tDBOutput_3 != 0) {
						int countSum_tDBOutput_3 = 0;

						for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

						insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_3 = 0;
					for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_3 = 0;

				if (pstmt_tDBOutput_3 != null) {

					pstmt_tDBOutput_3.close();
					resourceMap.remove("pstmt_tDBOutput_3");

				}
				resourceMap.put("statementClosed_tDBOutput_3", true);
				if (commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {

				}
				conn_tDBOutput_3.commit();
				if (commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {

					rowsToCommitCount_tDBOutput_3 = 0;
				}
				commitCounter_tDBOutput_3 = 0;

				conn_tDBOutput_3.close();

				resourceMap.put("finish_tDBOutput_3", true);

				nb_line_deleted_tDBOutput_3 = nb_line_deleted_tDBOutput_3 + deletedCount_tDBOutput_3;
				nb_line_update_tDBOutput_3 = nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
				nb_line_inserted_tDBOutput_3 = nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
				nb_line_rejected_tDBOutput_3 = nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;

				globalMap.put("tDBOutput_3_NB_LINE", nb_line_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_UPDATED", nb_line_update_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_DELETED", nb_line_deleted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "deposit");
				}

				ok_Hash.put("tDBOutput_3", true);
				end_Hash.put("tDBOutput_3", System.currentTimeMillis());

				/**
				 * [tDBOutput_3 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_3 finally ] start
				 */

				currentComponent = "tFileInputDelimited_3";

				/**
				 * [tFileInputDelimited_3 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tDBOutput_3 finally ] start
				 */

				currentComponent = "tDBOutput_3";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
						if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_3")) != null) {
							pstmtToClose_tDBOutput_3.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_3") == null) {
						java.sql.Connection ctn_tDBOutput_3 = null;
						if ((ctn_tDBOutput_3 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_3")) != null) {
							try {
								ctn_tDBOutput_3.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_3) {
								String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :"
										+ sqlEx_tDBOutput_3.getMessage();
								System.err.println(errorMessage_tDBOutput_3);
							}
						}
					}
				}

				/**
				 * [tDBOutput_3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 1);
	}

	public static class guesttStruct implements routines.system.IPersistableRow<guesttStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_guest;

		public int getId_guest() {
			return this.id_guest;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public Boolean is_repeated;

		public Boolean getIs_repeated() {
			return this.is_repeated;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_cancelled;

		public Integer getPrevious_bookings_not_cancelled() {
			return this.previous_bookings_not_cancelled;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_guest;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final guesttStruct other = (guesttStruct) obj;

			if (this.id_guest != other.id_guest)
				return false;

			return true;
		}

		public void copyDataTo(guesttStruct other) {

			other.id_guest = this.id_guest;
			other.country = this.country;
			other.is_repeated = this.is_repeated;
			other.previous_cancellations = this.previous_cancellations;
			other.previous_bookings_not_cancelled = this.previous_bookings_not_cancelled;

		}

		public void copyKeysDataTo(guesttStruct other) {

			other.id_guest = this.id_guest;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_guest = dis.readInt();

					this.country = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.is_repeated = null;
					} else {
						this.is_repeated = dis.readBoolean();
					}

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_cancelled = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_guest = dis.readInt();

					this.country = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.is_repeated = null;
					} else {
						this.is_repeated = dis.readBoolean();
					}

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_cancelled = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_guest);

				// String

				writeString(this.country, dos);

				// Boolean

				if (this.is_repeated == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.is_repeated);
				}

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_cancelled, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_guest);

				// String

				writeString(this.country, dos);

				// Boolean

				if (this.is_repeated == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.is_repeated);
				}

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_cancelled, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_guest=" + String.valueOf(id_guest));
			sb.append(",country=" + country);
			sb.append(",is_repeated=" + String.valueOf(is_repeated));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_cancelled=" + String.valueOf(previous_bookings_not_cancelled));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(guesttStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_guest, other.id_guest);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Boolean is_repeated_guest;

		public Boolean getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.is_repeated_guest = null;
					} else {
						this.is_repeated_guest = dis.readBoolean();
					}

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.is_repeated_guest = null;
					} else {
						this.is_repeated_guest = dis.readBoolean();
					}

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Boolean

				if (this.is_repeated_guest == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.is_repeated_guest);
				}

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Boolean

				if (this.is_repeated_guest == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.is_repeated_guest);
				}

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();
				guesttStruct guestt = new guesttStruct();

				/**
				 * [tDBOutput_4 begin ] start
				 */

				ok_Hash.put("tDBOutput_4", false);
				start_Hash.put("tDBOutput_4", System.currentTimeMillis());

				currentComponent = "tDBOutput_4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "guestt");
				}

				int tos_count_tDBOutput_4 = 0;

				int nb_line_tDBOutput_4 = 0;
				int nb_line_update_tDBOutput_4 = 0;
				int nb_line_inserted_tDBOutput_4 = 0;
				int nb_line_deleted_tDBOutput_4 = 0;
				int nb_line_rejected_tDBOutput_4 = 0;

				int deletedCount_tDBOutput_4 = 0;
				int updatedCount_tDBOutput_4 = 0;
				int insertedCount_tDBOutput_4 = 0;
				int rowsToCommitCount_tDBOutput_4 = 0;
				int rejectedCount_tDBOutput_4 = 0;

				String tableName_tDBOutput_4 = "dim_guest";
				boolean whetherReject_tDBOutput_4 = false;

				java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
				calendar_tDBOutput_4.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
				calendar_tDBOutput_4.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
				long date_tDBOutput_4;

				java.sql.Connection conn_tDBOutput_4 = null;

				String properties_tDBOutput_4 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_4 == null || properties_tDBOutput_4.trim().length() == 0) {
					properties_tDBOutput_4 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_4.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_4 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_4.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_4 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_4 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_4;

				String driverClass_tDBOutput_4 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_4 = "root";

				final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:6CkcK2rWfe2xFPG0Pwvm4DUaw1XtDnw30ywIfQ==");

				String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;
				java.lang.Class.forName(driverClass_tDBOutput_4);

				conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4, dbUser_tDBOutput_4,
						dbPwd_tDBOutput_4);

				resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);
				conn_tDBOutput_4.setAutoCommit(false);
				int commitEvery_tDBOutput_4 = 10000;
				int commitCounter_tDBOutput_4 = 0;

				int count_tDBOutput_4 = 0;

				String insert_tDBOutput_4 = "INSERT INTO `" + "dim_guest"
						+ "` (`id_guest`,`country`,`is_repeated`,`previous_cancellations`,`previous_bookings_not_cancelled`) VALUES (?,?,?,?,?)";
				int batchSize_tDBOutput_4 = 100;
				int batchSizeCounter_tDBOutput_4 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);

				/**
				 * [tDBOutput_4 begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tMap_4 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				guesttStruct guestt_tmp = new guesttStruct();
// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_4 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_4", false);
				start_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_4";

				int tos_count_tFileInputDelimited_4 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_4 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_4 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_4 = null;
				int limit_tFileInputDelimited_4 = -1;
				try {

					Object filename_tFileInputDelimited_4 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_4 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_4 = 0, random_value_tFileInputDelimited_4 = -1;
						if (footer_value_tFileInputDelimited_4 > 0 || random_value_tFileInputDelimited_4 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_4 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_4, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_4 != null && fid_tFileInputDelimited_4.nextRecord()) {
						rowstate_tFileInputDelimited_4.reset();

						row4 = null;

						boolean whetherReject_tFileInputDelimited_4 = false;
						row4 = new row4Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_4 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_4 = 0;

							row4.hotel = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 1;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 2;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 3;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 4;

							row4.arrival_date_month = fid_tFileInputDelimited_4
									.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 5;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 6;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 7;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 8;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 9;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 10;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.children = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 11;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 12;

							row4.meal = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 13;

							row4.country = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 14;

							row4.market_segment = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 15;

							row4.distribution_channel = fid_tFileInputDelimited_4
									.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 16;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.is_repeated_guest = ParserUtils.parseTo_Boolean(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 17;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 18;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 19;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 20;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 21;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 22;

							row4.deposit_type = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 23;

							row4.agent = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 24;

							row4.company = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 25;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 26;

							row4.customer_type = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 27;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row4", temp, ex_tFileInputDelimited_4), ex_tFileInputDelimited_4));
								}

							} else {

								row4.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 28;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 29;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_4 = 30;

							row4.reservation_status = fid_tFileInputDelimited_4
									.get(columnIndexWithD_tFileInputDelimited_4);

							columnIndexWithD_tFileInputDelimited_4 = 31;

							temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
							if (temp.length() > 0) {

								try {

									row4.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_4) {
									globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",
											ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row4", temp, ex_tFileInputDelimited_4),
											ex_tFileInputDelimited_4));
								}

							} else {

								row4.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_4.getException() != null) {
								throw rowstate_tFileInputDelimited_4.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_4 = true;

							System.err.println(e.getMessage());
							row4 = null;

						}

						/**
						 * [tFileInputDelimited_4 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_4 main ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						tos_count_tFileInputDelimited_4++;

						/**
						 * [tFileInputDelimited_4 main ] stop
						 */

						/**
						 * [tFileInputDelimited_4 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						/**
						 * [tFileInputDelimited_4 process_data_begin ] stop
						 */
// Start of branch "row4"
						if (row4 != null) {

							/**
							 * [tMap_4 main ] start
							 */

							currentComponent = "tMap_4";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row4"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_4 = false;
							boolean mainRowRejected_tMap_4 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
								// ###############################
								// # Output tables

								guestt = null;

// # Output table : 'guestt'
								guestt_tmp.id_guest = 0;
								guestt_tmp.country = row4.country;
								guestt_tmp.is_repeated = row4.is_repeated_guest;
								guestt_tmp.previous_cancellations = row4.previous_cancellations;
								guestt_tmp.previous_bookings_not_cancelled = row4.previous_bookings_not_canceled;
								guestt = guestt_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_4 = false;

							tos_count_tMap_4++;

							/**
							 * [tMap_4 main ] stop
							 */

							/**
							 * [tMap_4 process_data_begin ] start
							 */

							currentComponent = "tMap_4";

							/**
							 * [tMap_4 process_data_begin ] stop
							 */
// Start of branch "guestt"
							if (guestt != null) {

								/**
								 * [tDBOutput_4 main ] start
								 */

								currentComponent = "tDBOutput_4";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "guestt"

									);
								}

								whetherReject_tDBOutput_4 = false;
								pstmt_tDBOutput_4.setInt(1, guestt.id_guest);

								if (guestt.country == null) {
									pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_4.setString(2, guestt.country);
								}

								if (guestt.is_repeated == null) {
									pstmt_tDBOutput_4.setNull(3, java.sql.Types.BOOLEAN);
								} else {
									pstmt_tDBOutput_4.setBoolean(3, guestt.is_repeated);
								}

								if (guestt.previous_cancellations == null) {
									pstmt_tDBOutput_4.setNull(4, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_4.setInt(4, guestt.previous_cancellations);
								}

								if (guestt.previous_bookings_not_cancelled == null) {
									pstmt_tDBOutput_4.setNull(5, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_4.setInt(5, guestt.previous_bookings_not_cancelled);
								}

								pstmt_tDBOutput_4.addBatch();
								nb_line_tDBOutput_4++;

								batchSizeCounter_tDBOutput_4++;
								if (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4) {
									try {
										int countSum_tDBOutput_4 = 0;
										for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
											countSum_tDBOutput_4 += (countEach_tDBOutput_4 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
										insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_4 = 0;
										for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
											countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0
													: countEach_tDBOutput_4);
										}
										rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
										insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_4 = 0;
								}
								commitCounter_tDBOutput_4++;

								if (commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {

									try {
										int countSum_tDBOutput_4 = 0;
										for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
											countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
										insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_4 = 0;
										for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
											countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0
													: countEach_tDBOutput_4);
										}
										rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
										insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_4 != 0) {
									}
									conn_tDBOutput_4.commit();
									if (rowsToCommitCount_tDBOutput_4 != 0) {
										rowsToCommitCount_tDBOutput_4 = 0;
									}
									commitCounter_tDBOutput_4 = 0;

								}

								tos_count_tDBOutput_4++;

								/**
								 * [tDBOutput_4 main ] stop
								 */

								/**
								 * [tDBOutput_4 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_4";

								/**
								 * [tDBOutput_4 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_4 process_data_end ] start
								 */

								currentComponent = "tDBOutput_4";

								/**
								 * [tDBOutput_4 process_data_end ] stop
								 */

							} // End of branch "guestt"

							/**
							 * [tMap_4 process_data_end ] start
							 */

							currentComponent = "tMap_4";

							/**
							 * [tMap_4 process_data_end ] stop
							 */

						} // End of branch "row4"

						/**
						 * [tFileInputDelimited_4 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						/**
						 * [tFileInputDelimited_4 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_4 end ] start
						 */

						currentComponent = "tFileInputDelimited_4";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_4 != null) {
							fid_tFileInputDelimited_4.close();
						}
					}
					if (fid_tFileInputDelimited_4 != null) {
						globalMap.put("tFileInputDelimited_4_NB_LINE", fid_tFileInputDelimited_4.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_4", true);
				end_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_4 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tDBOutput_4 end ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					if (batchSizeCounter_tDBOutput_4 != 0) {
						int countSum_tDBOutput_4 = 0;

						for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

						insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_4 = 0;
					for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_4 = 0;

				if (pstmt_tDBOutput_4 != null) {

					pstmt_tDBOutput_4.close();
					resourceMap.remove("pstmt_tDBOutput_4");

				}
				resourceMap.put("statementClosed_tDBOutput_4", true);
				if (commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {

				}
				conn_tDBOutput_4.commit();
				if (commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {

					rowsToCommitCount_tDBOutput_4 = 0;
				}
				commitCounter_tDBOutput_4 = 0;

				conn_tDBOutput_4.close();

				resourceMap.put("finish_tDBOutput_4", true);

				nb_line_deleted_tDBOutput_4 = nb_line_deleted_tDBOutput_4 + deletedCount_tDBOutput_4;
				nb_line_update_tDBOutput_4 = nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
				nb_line_inserted_tDBOutput_4 = nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
				nb_line_rejected_tDBOutput_4 = nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;

				globalMap.put("tDBOutput_4_NB_LINE", nb_line_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_UPDATED", nb_line_update_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_DELETED", nb_line_deleted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "guestt");
				}

				ok_Hash.put("tDBOutput_4", true);
				end_Hash.put("tDBOutput_4", System.currentTimeMillis());

				/**
				 * [tDBOutput_4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_4 finally ] start
				 */

				currentComponent = "tFileInputDelimited_4";

				/**
				 * [tFileInputDelimited_4 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tDBOutput_4 finally ] start
				 */

				currentComponent = "tDBOutput_4";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
						if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_4")) != null) {
							pstmtToClose_tDBOutput_4.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_4") == null) {
						java.sql.Connection ctn_tDBOutput_4 = null;
						if ((ctn_tDBOutput_4 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_4")) != null) {
							try {
								ctn_tDBOutput_4.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_4) {
								String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :"
										+ sqlEx_tDBOutput_4.getMessage();
								System.err.println(errorMessage_tDBOutput_4);
							}
						}
					}
				}

				/**
				 * [tDBOutput_4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 1);
	}

	public static class hotelStruct implements routines.system.IPersistableRow<hotelStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_hotel;

		public int getId_hotel() {
			return this.id_hotel;
		}

		public String hotel_type;

		public String getHotel_type() {
			return this.hotel_type;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_hotel;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final hotelStruct other = (hotelStruct) obj;

			if (this.id_hotel != other.id_hotel)
				return false;

			return true;
		}

		public void copyDataTo(hotelStruct other) {

			other.id_hotel = this.id_hotel;
			other.hotel_type = this.hotel_type;

		}

		public void copyKeysDataTo(hotelStruct other) {

			other.id_hotel = this.id_hotel;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_hotel = dis.readInt();

					this.hotel_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_hotel = dis.readInt();

					this.hotel_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_hotel);

				// String

				writeString(this.hotel_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_hotel);

				// String

				writeString(this.hotel_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_hotel=" + String.valueOf(id_hotel));
			sb.append(",hotel_type=" + hotel_type);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(hotelStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_hotel, other.id_hotel);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row5Struct row5 = new row5Struct();
				hotelStruct hotel = new hotelStruct();

				/**
				 * [tDBOutput_5 begin ] start
				 */

				ok_Hash.put("tDBOutput_5", false);
				start_Hash.put("tDBOutput_5", System.currentTimeMillis());

				currentComponent = "tDBOutput_5";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "hotel");
				}

				int tos_count_tDBOutput_5 = 0;

				int nb_line_tDBOutput_5 = 0;
				int nb_line_update_tDBOutput_5 = 0;
				int nb_line_inserted_tDBOutput_5 = 0;
				int nb_line_deleted_tDBOutput_5 = 0;
				int nb_line_rejected_tDBOutput_5 = 0;

				int deletedCount_tDBOutput_5 = 0;
				int updatedCount_tDBOutput_5 = 0;
				int insertedCount_tDBOutput_5 = 0;
				int rowsToCommitCount_tDBOutput_5 = 0;
				int rejectedCount_tDBOutput_5 = 0;

				String tableName_tDBOutput_5 = "dim_hotel";
				boolean whetherReject_tDBOutput_5 = false;

				java.util.Calendar calendar_tDBOutput_5 = java.util.Calendar.getInstance();
				calendar_tDBOutput_5.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
				calendar_tDBOutput_5.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
				long date_tDBOutput_5;

				java.sql.Connection conn_tDBOutput_5 = null;

				String properties_tDBOutput_5 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_5 == null || properties_tDBOutput_5.trim().length() == 0) {
					properties_tDBOutput_5 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_5.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_5 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_5.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_5 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_5 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_5;

				String driverClass_tDBOutput_5 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_5 = "root";

				final String decryptedPassword_tDBOutput_5 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:WWRRUb4OUiKV5dQdpo2yCvtszdKdii1IXsgh5Q==");

				String dbPwd_tDBOutput_5 = decryptedPassword_tDBOutput_5;
				java.lang.Class.forName(driverClass_tDBOutput_5);

				conn_tDBOutput_5 = java.sql.DriverManager.getConnection(url_tDBOutput_5, dbUser_tDBOutput_5,
						dbPwd_tDBOutput_5);

				resourceMap.put("conn_tDBOutput_5", conn_tDBOutput_5);
				conn_tDBOutput_5.setAutoCommit(false);
				int commitEvery_tDBOutput_5 = 10000;
				int commitCounter_tDBOutput_5 = 0;

				int count_tDBOutput_5 = 0;

				String insert_tDBOutput_5 = "INSERT INTO `" + "dim_hotel" + "` (`id_hotel`,`hotel_type`) VALUES (?,?)";
				int batchSize_tDBOutput_5 = 100;
				int batchSizeCounter_tDBOutput_5 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
				resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);

				/**
				 * [tDBOutput_5 begin ] stop
				 */

				/**
				 * [tMap_5 begin ] start
				 */

				ok_Hash.put("tMap_5", false);
				start_Hash.put("tMap_5", System.currentTimeMillis());

				currentComponent = "tMap_5";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tMap_5 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_5__Struct {
				}
				Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				hotelStruct hotel_tmp = new hotelStruct();
// ###############################

				/**
				 * [tMap_5 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_5 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_5", false);
				start_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_5";

				int tos_count_tFileInputDelimited_5 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_5 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_5 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_5 = null;
				int limit_tFileInputDelimited_5 = -1;
				try {

					Object filename_tFileInputDelimited_5 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_5 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_5 = 0, random_value_tFileInputDelimited_5 = -1;
						if (footer_value_tFileInputDelimited_5 > 0 || random_value_tFileInputDelimited_5 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_5 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_5, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_5 != null && fid_tFileInputDelimited_5.nextRecord()) {
						rowstate_tFileInputDelimited_5.reset();

						row5 = null;

						boolean whetherReject_tFileInputDelimited_5 = false;
						row5 = new row5Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_5 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_5 = 0;

							row5.hotel = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 1;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 2;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 3;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 4;

							row5.arrival_date_month = fid_tFileInputDelimited_5
									.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 5;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 6;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 7;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 8;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 9;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 10;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.children = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 11;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 12;

							row5.meal = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 13;

							row5.country = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 14;

							row5.market_segment = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 15;

							row5.distribution_channel = fid_tFileInputDelimited_5
									.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 16;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 17;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 18;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 19;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 20;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 21;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 22;

							row5.deposit_type = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 23;

							row5.agent = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 24;

							row5.company = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 25;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 26;

							row5.customer_type = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 27;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row5", temp, ex_tFileInputDelimited_5), ex_tFileInputDelimited_5));
								}

							} else {

								row5.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 28;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 29;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 30;

							row5.reservation_status = fid_tFileInputDelimited_5
									.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 31;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row5.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row5", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row5.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_5.getException() != null) {
								throw rowstate_tFileInputDelimited_5.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_5 = true;

							System.err.println(e.getMessage());
							row5 = null;

						}

						/**
						 * [tFileInputDelimited_5 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_5 main ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						tos_count_tFileInputDelimited_5++;

						/**
						 * [tFileInputDelimited_5 main ] stop
						 */

						/**
						 * [tFileInputDelimited_5 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						/**
						 * [tFileInputDelimited_5 process_data_begin ] stop
						 */
// Start of branch "row5"
						if (row5 != null) {

							/**
							 * [tMap_5 main ] start
							 */

							currentComponent = "tMap_5";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row5"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_5 = false;
							boolean mainRowRejected_tMap_5 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
								// ###############################
								// # Output tables

								hotel = null;

// # Output table : 'hotel'
								hotel_tmp.id_hotel = 0;
								hotel_tmp.hotel_type = row5.hotel;
								hotel = hotel_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_5 = false;

							tos_count_tMap_5++;

							/**
							 * [tMap_5 main ] stop
							 */

							/**
							 * [tMap_5 process_data_begin ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_begin ] stop
							 */
// Start of branch "hotel"
							if (hotel != null) {

								/**
								 * [tDBOutput_5 main ] start
								 */

								currentComponent = "tDBOutput_5";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "hotel"

									);
								}

								whetherReject_tDBOutput_5 = false;
								pstmt_tDBOutput_5.setInt(1, hotel.id_hotel);

								if (hotel.hotel_type == null) {
									pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_5.setString(2, hotel.hotel_type);
								}

								pstmt_tDBOutput_5.addBatch();
								nb_line_tDBOutput_5++;

								batchSizeCounter_tDBOutput_5++;
								if (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5) {
									try {
										int countSum_tDBOutput_5 = 0;
										for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
											countSum_tDBOutput_5 += (countEach_tDBOutput_5 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
										insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_5 = 0;
										for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
											countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0
													: countEach_tDBOutput_5);
										}
										rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
										insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_5 = 0;
								}
								commitCounter_tDBOutput_5++;

								if (commitEvery_tDBOutput_5 <= commitCounter_tDBOutput_5) {

									try {
										int countSum_tDBOutput_5 = 0;
										for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
											countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
										insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_5 = 0;
										for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
											countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0
													: countEach_tDBOutput_5);
										}
										rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
										insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_5 != 0) {
									}
									conn_tDBOutput_5.commit();
									if (rowsToCommitCount_tDBOutput_5 != 0) {
										rowsToCommitCount_tDBOutput_5 = 0;
									}
									commitCounter_tDBOutput_5 = 0;

								}

								tos_count_tDBOutput_5++;

								/**
								 * [tDBOutput_5 main ] stop
								 */

								/**
								 * [tDBOutput_5 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_5";

								/**
								 * [tDBOutput_5 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_5 process_data_end ] start
								 */

								currentComponent = "tDBOutput_5";

								/**
								 * [tDBOutput_5 process_data_end ] stop
								 */

							} // End of branch "hotel"

							/**
							 * [tMap_5 process_data_end ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_end ] stop
							 */

						} // End of branch "row5"

						/**
						 * [tFileInputDelimited_5 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						/**
						 * [tFileInputDelimited_5 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_5 end ] start
						 */

						currentComponent = "tFileInputDelimited_5";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_5 != null) {
							fid_tFileInputDelimited_5.close();
						}
					}
					if (fid_tFileInputDelimited_5 != null) {
						globalMap.put("tFileInputDelimited_5_NB_LINE", fid_tFileInputDelimited_5.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_5", true);
				end_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_5 end ] stop
				 */

				/**
				 * [tMap_5 end ] start
				 */

				currentComponent = "tMap_5";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tMap_5", true);
				end_Hash.put("tMap_5", System.currentTimeMillis());

				/**
				 * [tMap_5 end ] stop
				 */

				/**
				 * [tDBOutput_5 end ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					if (batchSizeCounter_tDBOutput_5 != 0) {
						int countSum_tDBOutput_5 = 0;

						for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

						insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_5 = 0;
					for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_5 = 0;

				if (pstmt_tDBOutput_5 != null) {

					pstmt_tDBOutput_5.close();
					resourceMap.remove("pstmt_tDBOutput_5");

				}
				resourceMap.put("statementClosed_tDBOutput_5", true);
				if (commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {

				}
				conn_tDBOutput_5.commit();
				if (commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {

					rowsToCommitCount_tDBOutput_5 = 0;
				}
				commitCounter_tDBOutput_5 = 0;

				conn_tDBOutput_5.close();

				resourceMap.put("finish_tDBOutput_5", true);

				nb_line_deleted_tDBOutput_5 = nb_line_deleted_tDBOutput_5 + deletedCount_tDBOutput_5;
				nb_line_update_tDBOutput_5 = nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
				nb_line_inserted_tDBOutput_5 = nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
				nb_line_rejected_tDBOutput_5 = nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;

				globalMap.put("tDBOutput_5_NB_LINE", nb_line_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_UPDATED", nb_line_update_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_DELETED", nb_line_deleted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "hotel");
				}

				ok_Hash.put("tDBOutput_5", true);
				end_Hash.put("tDBOutput_5", System.currentTimeMillis());

				/**
				 * [tDBOutput_5 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_5 finally ] start
				 */

				currentComponent = "tFileInputDelimited_5";

				/**
				 * [tFileInputDelimited_5 finally ] stop
				 */

				/**
				 * [tMap_5 finally ] start
				 */

				currentComponent = "tMap_5";

				/**
				 * [tMap_5 finally ] stop
				 */

				/**
				 * [tDBOutput_5 finally ] start
				 */

				currentComponent = "tDBOutput_5";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
						if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_5")) != null) {
							pstmtToClose_tDBOutput_5.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_5") == null) {
						java.sql.Connection ctn_tDBOutput_5 = null;
						if ((ctn_tDBOutput_5 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_5")) != null) {
							try {
								ctn_tDBOutput_5.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_5) {
								String errorMessage_tDBOutput_5 = "failed to close the connection in tDBOutput_5 :"
										+ sqlEx_tDBOutput_5.getMessage();
								System.err.println(errorMessage_tDBOutput_5);
							}
						}
					}
				}

				/**
				 * [tDBOutput_5 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 1);
	}

	public static class mealStruct implements routines.system.IPersistableRow<mealStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_meal;

		public int getId_meal() {
			return this.id_meal;
		}

		public String meal_code;

		public String getMeal_code() {
			return this.meal_code;
		}

		public String meal_type;

		public String getMeal_type() {
			return this.meal_type;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_meal;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final mealStruct other = (mealStruct) obj;

			if (this.id_meal != other.id_meal)
				return false;

			return true;
		}

		public void copyDataTo(mealStruct other) {

			other.id_meal = this.id_meal;
			other.meal_code = this.meal_code;
			other.meal_type = this.meal_type;

		}

		public void copyKeysDataTo(mealStruct other) {

			other.id_meal = this.id_meal;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_meal = dis.readInt();

					this.meal_code = readString(dis);

					this.meal_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_meal = dis.readInt();

					this.meal_code = readString(dis);

					this.meal_type = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_meal);

				// String

				writeString(this.meal_code, dos);

				// String

				writeString(this.meal_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_meal);

				// String

				writeString(this.meal_code, dos);

				// String

				writeString(this.meal_type, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_meal=" + String.valueOf(id_meal));
			sb.append(",meal_code=" + meal_code);
			sb.append(",meal_type=" + meal_type);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(mealStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_meal, other.id_meal);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row6Struct row6 = new row6Struct();
				mealStruct meal = new mealStruct();

				/**
				 * [tDBOutput_6 begin ] start
				 */

				ok_Hash.put("tDBOutput_6", false);
				start_Hash.put("tDBOutput_6", System.currentTimeMillis());

				currentComponent = "tDBOutput_6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "meal");
				}

				int tos_count_tDBOutput_6 = 0;

				int nb_line_tDBOutput_6 = 0;
				int nb_line_update_tDBOutput_6 = 0;
				int nb_line_inserted_tDBOutput_6 = 0;
				int nb_line_deleted_tDBOutput_6 = 0;
				int nb_line_rejected_tDBOutput_6 = 0;

				int deletedCount_tDBOutput_6 = 0;
				int updatedCount_tDBOutput_6 = 0;
				int insertedCount_tDBOutput_6 = 0;
				int rowsToCommitCount_tDBOutput_6 = 0;
				int rejectedCount_tDBOutput_6 = 0;

				String tableName_tDBOutput_6 = "dim_meal";
				boolean whetherReject_tDBOutput_6 = false;

				java.util.Calendar calendar_tDBOutput_6 = java.util.Calendar.getInstance();
				calendar_tDBOutput_6.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_6 = calendar_tDBOutput_6.getTime().getTime();
				calendar_tDBOutput_6.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_6 = calendar_tDBOutput_6.getTime().getTime();
				long date_tDBOutput_6;

				java.sql.Connection conn_tDBOutput_6 = null;

				String properties_tDBOutput_6 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_6 == null || properties_tDBOutput_6.trim().length() == 0) {
					properties_tDBOutput_6 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_6.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_6 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_6.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_6 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_6 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_6;

				String driverClass_tDBOutput_6 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_6 = "root";

				final String decryptedPassword_tDBOutput_6 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:dFuVWUnzu2BMGk7lknheFBnNwTs/Q+3yBRaWSg==");

				String dbPwd_tDBOutput_6 = decryptedPassword_tDBOutput_6;
				java.lang.Class.forName(driverClass_tDBOutput_6);

				conn_tDBOutput_6 = java.sql.DriverManager.getConnection(url_tDBOutput_6, dbUser_tDBOutput_6,
						dbPwd_tDBOutput_6);

				resourceMap.put("conn_tDBOutput_6", conn_tDBOutput_6);
				conn_tDBOutput_6.setAutoCommit(false);
				int commitEvery_tDBOutput_6 = 10000;
				int commitCounter_tDBOutput_6 = 0;

				int count_tDBOutput_6 = 0;

				String insert_tDBOutput_6 = "INSERT INTO `" + "dim_meal"
						+ "` (`id_meal`,`meal_code`,`meal_type`) VALUES (?,?,?)";
				int batchSize_tDBOutput_6 = 100;
				int batchSizeCounter_tDBOutput_6 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
				resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);

				/**
				 * [tDBOutput_6 begin ] stop
				 */

				/**
				 * [tMap_6 begin ] start
				 */

				ok_Hash.put("tMap_6", false);
				start_Hash.put("tMap_6", System.currentTimeMillis());

				currentComponent = "tMap_6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row6");
				}

				int tos_count_tMap_6 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_6__Struct {
				}
				Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				mealStruct meal_tmp = new mealStruct();
// ###############################

				/**
				 * [tMap_6 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_6 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_6", false);
				start_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_6";

				int tos_count_tFileInputDelimited_6 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_6 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_6 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_6 = null;
				int limit_tFileInputDelimited_6 = -1;
				try {

					Object filename_tFileInputDelimited_6 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_6 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_6 = 0, random_value_tFileInputDelimited_6 = -1;
						if (footer_value_tFileInputDelimited_6 > 0 || random_value_tFileInputDelimited_6 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_6 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_6, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_6 != null && fid_tFileInputDelimited_6.nextRecord()) {
						rowstate_tFileInputDelimited_6.reset();

						row6 = null;

						boolean whetherReject_tFileInputDelimited_6 = false;
						row6 = new row6Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_6 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_6 = 0;

							row6.hotel = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 1;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 2;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 3;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 4;

							row6.arrival_date_month = fid_tFileInputDelimited_6
									.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 5;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 6;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 7;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 8;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 9;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 10;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.children = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 11;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 12;

							row6.meal = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 13;

							row6.country = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 14;

							row6.market_segment = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 15;

							row6.distribution_channel = fid_tFileInputDelimited_6
									.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 16;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 17;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 18;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 19;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 20;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 21;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 22;

							row6.deposit_type = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 23;

							row6.agent = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 24;

							row6.company = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 25;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 26;

							row6.customer_type = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 27;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row6", temp, ex_tFileInputDelimited_6), ex_tFileInputDelimited_6));
								}

							} else {

								row6.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 28;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 29;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_6 = 30;

							row6.reservation_status = fid_tFileInputDelimited_6
									.get(columnIndexWithD_tFileInputDelimited_6);

							columnIndexWithD_tFileInputDelimited_6 = 31;

							temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
							if (temp.length() > 0) {

								try {

									row6.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_6) {
									globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
											ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row6", temp, ex_tFileInputDelimited_6),
											ex_tFileInputDelimited_6));
								}

							} else {

								row6.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_6.getException() != null) {
								throw rowstate_tFileInputDelimited_6.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_6 = true;

							System.err.println(e.getMessage());
							row6 = null;

						}

						/**
						 * [tFileInputDelimited_6 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_6 main ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						tos_count_tFileInputDelimited_6++;

						/**
						 * [tFileInputDelimited_6 main ] stop
						 */

						/**
						 * [tFileInputDelimited_6 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						/**
						 * [tFileInputDelimited_6 process_data_begin ] stop
						 */
// Start of branch "row6"
						if (row6 != null) {

							/**
							 * [tMap_6 main ] start
							 */

							currentComponent = "tMap_6";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row6"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_6 = false;
							boolean mainRowRejected_tMap_6 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
								// ###############################
								// # Output tables

								meal = null;

// # Output table : 'meal'
								meal_tmp.id_meal = 0;
								meal_tmp.meal_code = row6.meal;
								meal_tmp.meal_type = row6.meal;
								meal = meal_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_6 = false;

							tos_count_tMap_6++;

							/**
							 * [tMap_6 main ] stop
							 */

							/**
							 * [tMap_6 process_data_begin ] start
							 */

							currentComponent = "tMap_6";

							/**
							 * [tMap_6 process_data_begin ] stop
							 */
// Start of branch "meal"
							if (meal != null) {

								/**
								 * [tDBOutput_6 main ] start
								 */

								currentComponent = "tDBOutput_6";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "meal"

									);
								}

								whetherReject_tDBOutput_6 = false;
								pstmt_tDBOutput_6.setInt(1, meal.id_meal);

								if (meal.meal_code == null) {
									pstmt_tDBOutput_6.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_6.setString(2, meal.meal_code);
								}

								if (meal.meal_type == null) {
									pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_6.setString(3, meal.meal_type);
								}

								pstmt_tDBOutput_6.addBatch();
								nb_line_tDBOutput_6++;

								batchSizeCounter_tDBOutput_6++;
								if (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6) {
									try {
										int countSum_tDBOutput_6 = 0;
										for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
											countSum_tDBOutput_6 += (countEach_tDBOutput_6 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
										insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_6 = 0;
										for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
											countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0
													: countEach_tDBOutput_6);
										}
										rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
										insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_6 = 0;
								}
								commitCounter_tDBOutput_6++;

								if (commitEvery_tDBOutput_6 <= commitCounter_tDBOutput_6) {

									try {
										int countSum_tDBOutput_6 = 0;
										for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
											countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
										insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_6_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_6 = 0;
										for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
											countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0
													: countEach_tDBOutput_6);
										}
										rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
										insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_6 != 0) {
									}
									conn_tDBOutput_6.commit();
									if (rowsToCommitCount_tDBOutput_6 != 0) {
										rowsToCommitCount_tDBOutput_6 = 0;
									}
									commitCounter_tDBOutput_6 = 0;

								}

								tos_count_tDBOutput_6++;

								/**
								 * [tDBOutput_6 main ] stop
								 */

								/**
								 * [tDBOutput_6 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_6";

								/**
								 * [tDBOutput_6 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_6 process_data_end ] start
								 */

								currentComponent = "tDBOutput_6";

								/**
								 * [tDBOutput_6 process_data_end ] stop
								 */

							} // End of branch "meal"

							/**
							 * [tMap_6 process_data_end ] start
							 */

							currentComponent = "tMap_6";

							/**
							 * [tMap_6 process_data_end ] stop
							 */

						} // End of branch "row6"

						/**
						 * [tFileInputDelimited_6 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						/**
						 * [tFileInputDelimited_6 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_6 end ] start
						 */

						currentComponent = "tFileInputDelimited_6";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_6 != null) {
							fid_tFileInputDelimited_6.close();
						}
					}
					if (fid_tFileInputDelimited_6 != null) {
						globalMap.put("tFileInputDelimited_6_NB_LINE", fid_tFileInputDelimited_6.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_6", true);
				end_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_6 end ] stop
				 */

				/**
				 * [tMap_6 end ] start
				 */

				currentComponent = "tMap_6";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row6");
				}

				ok_Hash.put("tMap_6", true);
				end_Hash.put("tMap_6", System.currentTimeMillis());

				/**
				 * [tMap_6 end ] stop
				 */

				/**
				 * [tDBOutput_6 end ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					if (batchSizeCounter_tDBOutput_6 != 0) {
						int countSum_tDBOutput_6 = 0;

						for (int countEach_tDBOutput_6 : pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

						insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_6 = 0;
					for (int countEach_tDBOutput_6 : e.getUpdateCounts()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;

					insertedCount_tDBOutput_6 += countSum_tDBOutput_6;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_6 = 0;

				if (pstmt_tDBOutput_6 != null) {

					pstmt_tDBOutput_6.close();
					resourceMap.remove("pstmt_tDBOutput_6");

				}
				resourceMap.put("statementClosed_tDBOutput_6", true);
				if (commitCounter_tDBOutput_6 > 0 && rowsToCommitCount_tDBOutput_6 != 0) {

				}
				conn_tDBOutput_6.commit();
				if (commitCounter_tDBOutput_6 > 0 && rowsToCommitCount_tDBOutput_6 != 0) {

					rowsToCommitCount_tDBOutput_6 = 0;
				}
				commitCounter_tDBOutput_6 = 0;

				conn_tDBOutput_6.close();

				resourceMap.put("finish_tDBOutput_6", true);

				nb_line_deleted_tDBOutput_6 = nb_line_deleted_tDBOutput_6 + deletedCount_tDBOutput_6;
				nb_line_update_tDBOutput_6 = nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
				nb_line_inserted_tDBOutput_6 = nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
				nb_line_rejected_tDBOutput_6 = nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;

				globalMap.put("tDBOutput_6_NB_LINE", nb_line_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_UPDATED", nb_line_update_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_DELETED", nb_line_deleted_tDBOutput_6);
				globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "meal");
				}

				ok_Hash.put("tDBOutput_6", true);
				end_Hash.put("tDBOutput_6", System.currentTimeMillis());

				/**
				 * [tDBOutput_6 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_6 finally ] start
				 */

				currentComponent = "tFileInputDelimited_6";

				/**
				 * [tFileInputDelimited_6 finally ] stop
				 */

				/**
				 * [tMap_6 finally ] start
				 */

				currentComponent = "tMap_6";

				/**
				 * [tMap_6 finally ] stop
				 */

				/**
				 * [tDBOutput_6 finally ] start
				 */

				currentComponent = "tDBOutput_6";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
						if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_6")) != null) {
							pstmtToClose_tDBOutput_6.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_6") == null) {
						java.sql.Connection ctn_tDBOutput_6 = null;
						if ((ctn_tDBOutput_6 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_6")) != null) {
							try {
								ctn_tDBOutput_6.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_6) {
								String errorMessage_tDBOutput_6 = "failed to close the connection in tDBOutput_6 :"
										+ sqlEx_tDBOutput_6.getMessage();
								System.err.println(errorMessage_tDBOutput_6);
							}
						}
					}
				}

				/**
				 * [tDBOutput_6 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 1);
	}

	public static class room2Struct implements routines.system.IPersistableRow<room2Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_room;

		public int getId_room() {
			return this.id_room;
		}

		public Character room_type;

		public Character getRoom_type() {
			return this.room_type;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_room;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final room2Struct other = (room2Struct) obj;

			if (this.id_room != other.id_room)
				return false;

			return true;
		}

		public void copyDataTo(room2Struct other) {

			other.id_room = this.id_room;
			other.room_type = this.room_type;

		}

		public void copyKeysDataTo(room2Struct other) {

			other.id_room = this.id_room;

		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_room = dis.readInt();

					length = dis.readByte();
					if (length == -1) {
						this.room_type = null;
					} else {
						this.room_type = dis.readChar();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_room = dis.readInt();

					length = dis.readByte();
					if (length == -1) {
						this.room_type = null;
					} else {
						this.room_type = dis.readChar();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_room);

				// Character

				if (this.room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.room_type);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_room);

				// Character

				if (this.room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.room_type);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_room=" + String.valueOf(id_room));
			sb.append(",room_type=" + String.valueOf(room_type));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(room2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_room, other.id_room);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_7_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row7Struct row7 = new row7Struct();
				room2Struct room2 = new room2Struct();

				/**
				 * [tDBOutput_7 begin ] start
				 */

				ok_Hash.put("tDBOutput_7", false);
				start_Hash.put("tDBOutput_7", System.currentTimeMillis());

				currentComponent = "tDBOutput_7";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "room2");
				}

				int tos_count_tDBOutput_7 = 0;

				int nb_line_tDBOutput_7 = 0;
				int nb_line_update_tDBOutput_7 = 0;
				int nb_line_inserted_tDBOutput_7 = 0;
				int nb_line_deleted_tDBOutput_7 = 0;
				int nb_line_rejected_tDBOutput_7 = 0;

				int deletedCount_tDBOutput_7 = 0;
				int updatedCount_tDBOutput_7 = 0;
				int insertedCount_tDBOutput_7 = 0;
				int rowsToCommitCount_tDBOutput_7 = 0;
				int rejectedCount_tDBOutput_7 = 0;

				String tableName_tDBOutput_7 = "dim_room";
				boolean whetherReject_tDBOutput_7 = false;

				java.util.Calendar calendar_tDBOutput_7 = java.util.Calendar.getInstance();
				calendar_tDBOutput_7.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_7 = calendar_tDBOutput_7.getTime().getTime();
				calendar_tDBOutput_7.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_7 = calendar_tDBOutput_7.getTime().getTime();
				long date_tDBOutput_7;

				java.sql.Connection conn_tDBOutput_7 = null;

				String properties_tDBOutput_7 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_7 == null || properties_tDBOutput_7.trim().length() == 0) {
					properties_tDBOutput_7 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_7.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_7 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_7.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_7 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_7 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_7;

				String driverClass_tDBOutput_7 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_7 = "root";

				final String decryptedPassword_tDBOutput_7 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:EEbbyHmTOBxDkdvJeZ5COtRzVQK939xKU1mSHg==");

				String dbPwd_tDBOutput_7 = decryptedPassword_tDBOutput_7;
				java.lang.Class.forName(driverClass_tDBOutput_7);

				conn_tDBOutput_7 = java.sql.DriverManager.getConnection(url_tDBOutput_7, dbUser_tDBOutput_7,
						dbPwd_tDBOutput_7);

				resourceMap.put("conn_tDBOutput_7", conn_tDBOutput_7);
				conn_tDBOutput_7.setAutoCommit(false);
				int commitEvery_tDBOutput_7 = 10000;
				int commitCounter_tDBOutput_7 = 0;

				int count_tDBOutput_7 = 0;

				String insert_tDBOutput_7 = "INSERT INTO `" + "dim_room" + "` (`id_room`,`room_type`) VALUES (?,?)";
				int batchSize_tDBOutput_7 = 100;
				int batchSizeCounter_tDBOutput_7 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
				resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);

				/**
				 * [tDBOutput_7 begin ] stop
				 */

				/**
				 * [tMap_7 begin ] start
				 */

				ok_Hash.put("tMap_7", false);
				start_Hash.put("tMap_7", System.currentTimeMillis());

				currentComponent = "tMap_7";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row7");
				}

				int tos_count_tMap_7 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_7__Struct {
				}
				Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
				room2Struct room2_tmp = new room2Struct();
// ###############################

				/**
				 * [tMap_7 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_7 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_7", false);
				start_Hash.put("tFileInputDelimited_7", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_7";

				int tos_count_tFileInputDelimited_7 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_7 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_7 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_7 = null;
				int limit_tFileInputDelimited_7 = -1;
				try {

					Object filename_tFileInputDelimited_7 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_7 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_7 = 0, random_value_tFileInputDelimited_7 = -1;
						if (footer_value_tFileInputDelimited_7 > 0 || random_value_tFileInputDelimited_7 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_7 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_7, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_7 != null && fid_tFileInputDelimited_7.nextRecord()) {
						rowstate_tFileInputDelimited_7.reset();

						row7 = null;

						boolean whetherReject_tFileInputDelimited_7 = false;
						row7 = new row7Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_7 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_7 = 0;

							row7.hotel = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 1;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 2;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 3;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 4;

							row7.arrival_date_month = fid_tFileInputDelimited_7
									.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 5;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 6;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 7;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 8;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 9;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 10;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.children = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 11;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 12;

							row7.meal = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 13;

							row7.country = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 14;

							row7.market_segment = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 15;

							row7.distribution_channel = fid_tFileInputDelimited_7
									.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 16;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 17;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 18;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 19;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 20;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 21;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 22;

							row7.deposit_type = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 23;

							row7.agent = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 24;

							row7.company = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 25;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 26;

							row7.customer_type = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 27;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row7", temp, ex_tFileInputDelimited_7), ex_tFileInputDelimited_7));
								}

							} else {

								row7.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 28;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 29;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_7 = 30;

							row7.reservation_status = fid_tFileInputDelimited_7
									.get(columnIndexWithD_tFileInputDelimited_7);

							columnIndexWithD_tFileInputDelimited_7 = 31;

							temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
							if (temp.length() > 0) {

								try {

									row7.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_7) {
									globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",
											ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row7", temp, ex_tFileInputDelimited_7),
											ex_tFileInputDelimited_7));
								}

							} else {

								row7.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_7.getException() != null) {
								throw rowstate_tFileInputDelimited_7.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_7 = true;

							System.err.println(e.getMessage());
							row7 = null;

						}

						/**
						 * [tFileInputDelimited_7 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_7 main ] start
						 */

						currentComponent = "tFileInputDelimited_7";

						tos_count_tFileInputDelimited_7++;

						/**
						 * [tFileInputDelimited_7 main ] stop
						 */

						/**
						 * [tFileInputDelimited_7 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_7";

						/**
						 * [tFileInputDelimited_7 process_data_begin ] stop
						 */
// Start of branch "row7"
						if (row7 != null) {

							/**
							 * [tMap_7 main ] start
							 */

							currentComponent = "tMap_7";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row7"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_7 = false;
							boolean mainRowRejected_tMap_7 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
								// ###############################
								// # Output tables

								room2 = null;

// # Output table : 'room2'
								room2_tmp.id_room = 0;
								room2_tmp.room_type = row7.assigned_room_type;
								room2 = room2_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_7 = false;

							tos_count_tMap_7++;

							/**
							 * [tMap_7 main ] stop
							 */

							/**
							 * [tMap_7 process_data_begin ] start
							 */

							currentComponent = "tMap_7";

							/**
							 * [tMap_7 process_data_begin ] stop
							 */
// Start of branch "room2"
							if (room2 != null) {

								/**
								 * [tDBOutput_7 main ] start
								 */

								currentComponent = "tDBOutput_7";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "room2"

									);
								}

								whetherReject_tDBOutput_7 = false;
								pstmt_tDBOutput_7.setInt(1, room2.id_room);

								if (room2.room_type == null) {
									pstmt_tDBOutput_7.setNull(2, java.sql.Types.CHAR);
								} else {
									if (room2.room_type == null) {
										pstmt_tDBOutput_7.setNull(2, java.sql.Types.CHAR);
									} else if (room2.room_type == ' ') {
										pstmt_tDBOutput_7.setString(2, "");
									} else {
										pstmt_tDBOutput_7.setString(2, String.valueOf(room2.room_type));
									}
								}

								pstmt_tDBOutput_7.addBatch();
								nb_line_tDBOutput_7++;

								batchSizeCounter_tDBOutput_7++;
								if (batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7) {
									try {
										int countSum_tDBOutput_7 = 0;
										for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
											countSum_tDBOutput_7 += (countEach_tDBOutput_7 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
										insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_7 = 0;
										for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
											countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0
													: countEach_tDBOutput_7);
										}
										rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
										insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_7 = 0;
								}
								commitCounter_tDBOutput_7++;

								if (commitEvery_tDBOutput_7 <= commitCounter_tDBOutput_7) {

									try {
										int countSum_tDBOutput_7 = 0;
										for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
											countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
										insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_7_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_7 = 0;
										for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
											countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0
													: countEach_tDBOutput_7);
										}
										rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
										insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_7 != 0) {
									}
									conn_tDBOutput_7.commit();
									if (rowsToCommitCount_tDBOutput_7 != 0) {
										rowsToCommitCount_tDBOutput_7 = 0;
									}
									commitCounter_tDBOutput_7 = 0;

								}

								tos_count_tDBOutput_7++;

								/**
								 * [tDBOutput_7 main ] stop
								 */

								/**
								 * [tDBOutput_7 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_7";

								/**
								 * [tDBOutput_7 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_7 process_data_end ] start
								 */

								currentComponent = "tDBOutput_7";

								/**
								 * [tDBOutput_7 process_data_end ] stop
								 */

							} // End of branch "room2"

							/**
							 * [tMap_7 process_data_end ] start
							 */

							currentComponent = "tMap_7";

							/**
							 * [tMap_7 process_data_end ] stop
							 */

						} // End of branch "row7"

						/**
						 * [tFileInputDelimited_7 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_7";

						/**
						 * [tFileInputDelimited_7 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_7 end ] start
						 */

						currentComponent = "tFileInputDelimited_7";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_7 != null) {
							fid_tFileInputDelimited_7.close();
						}
					}
					if (fid_tFileInputDelimited_7 != null) {
						globalMap.put("tFileInputDelimited_7_NB_LINE", fid_tFileInputDelimited_7.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_7", true);
				end_Hash.put("tFileInputDelimited_7", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_7 end ] stop
				 */

				/**
				 * [tMap_7 end ] start
				 */

				currentComponent = "tMap_7";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row7");
				}

				ok_Hash.put("tMap_7", true);
				end_Hash.put("tMap_7", System.currentTimeMillis());

				/**
				 * [tMap_7 end ] stop
				 */

				/**
				 * [tDBOutput_7 end ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					if (batchSizeCounter_tDBOutput_7 != 0) {
						int countSum_tDBOutput_7 = 0;

						for (int countEach_tDBOutput_7 : pstmt_tDBOutput_7.executeBatch()) {
							countSum_tDBOutput_7 += (countEach_tDBOutput_7 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

						insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_7 = 0;
					for (int countEach_tDBOutput_7 : e.getUpdateCounts()) {
						countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
					}
					rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;

					insertedCount_tDBOutput_7 += countSum_tDBOutput_7;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_7 = 0;

				if (pstmt_tDBOutput_7 != null) {

					pstmt_tDBOutput_7.close();
					resourceMap.remove("pstmt_tDBOutput_7");

				}
				resourceMap.put("statementClosed_tDBOutput_7", true);
				if (commitCounter_tDBOutput_7 > 0 && rowsToCommitCount_tDBOutput_7 != 0) {

				}
				conn_tDBOutput_7.commit();
				if (commitCounter_tDBOutput_7 > 0 && rowsToCommitCount_tDBOutput_7 != 0) {

					rowsToCommitCount_tDBOutput_7 = 0;
				}
				commitCounter_tDBOutput_7 = 0;

				conn_tDBOutput_7.close();

				resourceMap.put("finish_tDBOutput_7", true);

				nb_line_deleted_tDBOutput_7 = nb_line_deleted_tDBOutput_7 + deletedCount_tDBOutput_7;
				nb_line_update_tDBOutput_7 = nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
				nb_line_inserted_tDBOutput_7 = nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
				nb_line_rejected_tDBOutput_7 = nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;

				globalMap.put("tDBOutput_7_NB_LINE", nb_line_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_UPDATED", nb_line_update_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_DELETED", nb_line_deleted_tDBOutput_7);
				globalMap.put("tDBOutput_7_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_7);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "room2");
				}

				ok_Hash.put("tDBOutput_7", true);
				end_Hash.put("tDBOutput_7", System.currentTimeMillis());

				/**
				 * [tDBOutput_7 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_7 finally ] start
				 */

				currentComponent = "tFileInputDelimited_7";

				/**
				 * [tFileInputDelimited_7 finally ] stop
				 */

				/**
				 * [tMap_7 finally ] start
				 */

				currentComponent = "tMap_7";

				/**
				 * [tMap_7 finally ] stop
				 */

				/**
				 * [tDBOutput_7 finally ] start
				 */

				currentComponent = "tDBOutput_7";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
						if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_7")) != null) {
							pstmtToClose_tDBOutput_7.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_7") == null) {
						java.sql.Connection ctn_tDBOutput_7 = null;
						if ((ctn_tDBOutput_7 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_7")) != null) {
							try {
								ctn_tDBOutput_7.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_7) {
								String errorMessage_tDBOutput_7 = "failed to close the connection in tDBOutput_7 :"
										+ sqlEx_tDBOutput_7.getMessage();
								System.err.println(errorMessage_tDBOutput_7);
							}
						}
					}
				}

				/**
				 * [tDBOutput_7 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_7_SUBPROCESS_STATE", 1);
	}

	public static class channelStruct implements routines.system.IPersistableRow<channelStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_channel;

		public int getId_channel() {
			return this.id_channel;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_channel;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final channelStruct other = (channelStruct) obj;

			if (this.id_channel != other.id_channel)
				return false;

			return true;
		}

		public void copyDataTo(channelStruct other) {

			other.id_channel = this.id_channel;
			other.distribution_channel = this.distribution_channel;
			other.market_segment = this.market_segment;

		}

		public void copyKeysDataTo(channelStruct other) {

			other.id_channel = this.id_channel;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_channel = dis.readInt();

					this.distribution_channel = readString(dis);

					this.market_segment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_channel = dis.readInt();

					this.distribution_channel = readString(dis);

					this.market_segment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_channel);

				// String

				writeString(this.distribution_channel, dos);

				// String

				writeString(this.market_segment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_channel);

				// String

				writeString(this.distribution_channel, dos);

				// String

				writeString(this.market_segment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_channel=" + String.valueOf(id_channel));
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",market_segment=" + market_segment);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(channelStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_channel, other.id_channel);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_8_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row8Struct row8 = new row8Struct();
				channelStruct channel = new channelStruct();

				/**
				 * [tDBOutput_8 begin ] start
				 */

				ok_Hash.put("tDBOutput_8", false);
				start_Hash.put("tDBOutput_8", System.currentTimeMillis());

				currentComponent = "tDBOutput_8";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "channel");
				}

				int tos_count_tDBOutput_8 = 0;

				int nb_line_tDBOutput_8 = 0;
				int nb_line_update_tDBOutput_8 = 0;
				int nb_line_inserted_tDBOutput_8 = 0;
				int nb_line_deleted_tDBOutput_8 = 0;
				int nb_line_rejected_tDBOutput_8 = 0;

				int deletedCount_tDBOutput_8 = 0;
				int updatedCount_tDBOutput_8 = 0;
				int insertedCount_tDBOutput_8 = 0;
				int rowsToCommitCount_tDBOutput_8 = 0;
				int rejectedCount_tDBOutput_8 = 0;

				String tableName_tDBOutput_8 = "dim_sales_channel";
				boolean whetherReject_tDBOutput_8 = false;

				java.util.Calendar calendar_tDBOutput_8 = java.util.Calendar.getInstance();
				calendar_tDBOutput_8.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_8 = calendar_tDBOutput_8.getTime().getTime();
				calendar_tDBOutput_8.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_8 = calendar_tDBOutput_8.getTime().getTime();
				long date_tDBOutput_8;

				java.sql.Connection conn_tDBOutput_8 = null;

				String properties_tDBOutput_8 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_8 == null || properties_tDBOutput_8.trim().length() == 0) {
					properties_tDBOutput_8 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_8.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_8 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_8.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_8 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_8 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_8;

				String driverClass_tDBOutput_8 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_8 = "root";

				final String decryptedPassword_tDBOutput_8 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:rOzHA/FOU5Qmzlay/XKY5VQe4483lnRR01Q/TA==");

				String dbPwd_tDBOutput_8 = decryptedPassword_tDBOutput_8;
				java.lang.Class.forName(driverClass_tDBOutput_8);

				conn_tDBOutput_8 = java.sql.DriverManager.getConnection(url_tDBOutput_8, dbUser_tDBOutput_8,
						dbPwd_tDBOutput_8);

				resourceMap.put("conn_tDBOutput_8", conn_tDBOutput_8);
				conn_tDBOutput_8.setAutoCommit(false);
				int commitEvery_tDBOutput_8 = 10000;
				int commitCounter_tDBOutput_8 = 0;

				int count_tDBOutput_8 = 0;

				String insert_tDBOutput_8 = "INSERT INTO `" + "dim_sales_channel"
						+ "` (`id_channel`,`distribution_channel`,`market_segment`) VALUES (?,?,?)";
				int batchSize_tDBOutput_8 = 100;
				int batchSizeCounter_tDBOutput_8 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(insert_tDBOutput_8);
				resourceMap.put("pstmt_tDBOutput_8", pstmt_tDBOutput_8);

				/**
				 * [tDBOutput_8 begin ] stop
				 */

				/**
				 * [tMap_8 begin ] start
				 */

				ok_Hash.put("tMap_8", false);
				start_Hash.put("tMap_8", System.currentTimeMillis());

				currentComponent = "tMap_8";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row8");
				}

				int tos_count_tMap_8 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_8__Struct {
				}
				Var__tMap_8__Struct Var__tMap_8 = new Var__tMap_8__Struct();
// ###############################

// ###############################
// # Outputs initialization
				channelStruct channel_tmp = new channelStruct();
// ###############################

				/**
				 * [tMap_8 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_8 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_8", false);
				start_Hash.put("tFileInputDelimited_8", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_8";

				int tos_count_tFileInputDelimited_8 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_8 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_8 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_8 = null;
				int limit_tFileInputDelimited_8 = -1;
				try {

					Object filename_tFileInputDelimited_8 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_8 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_8 = 0, random_value_tFileInputDelimited_8 = -1;
						if (footer_value_tFileInputDelimited_8 > 0 || random_value_tFileInputDelimited_8 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_8 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_8, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_8 != null && fid_tFileInputDelimited_8.nextRecord()) {
						rowstate_tFileInputDelimited_8.reset();

						row8 = null;

						boolean whetherReject_tFileInputDelimited_8 = false;
						row8 = new row8Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_8 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_8 = 0;

							row8.hotel = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 1;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 2;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 3;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 4;

							row8.arrival_date_month = fid_tFileInputDelimited_8
									.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 5;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 6;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 7;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 8;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 9;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 10;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.children = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 11;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 12;

							row8.meal = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 13;

							row8.country = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 14;

							row8.market_segment = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 15;

							row8.distribution_channel = fid_tFileInputDelimited_8
									.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 16;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 17;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 18;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 19;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 20;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 21;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 22;

							row8.deposit_type = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 23;

							row8.agent = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 24;

							row8.company = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 25;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 26;

							row8.customer_type = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 27;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row8", temp, ex_tFileInputDelimited_8), ex_tFileInputDelimited_8));
								}

							} else {

								row8.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 28;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 29;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_8 = 30;

							row8.reservation_status = fid_tFileInputDelimited_8
									.get(columnIndexWithD_tFileInputDelimited_8);

							columnIndexWithD_tFileInputDelimited_8 = 31;

							temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
							if (temp.length() > 0) {

								try {

									row8.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_8) {
									globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",
											ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row8", temp, ex_tFileInputDelimited_8),
											ex_tFileInputDelimited_8));
								}

							} else {

								row8.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_8.getException() != null) {
								throw rowstate_tFileInputDelimited_8.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_8 = true;

							System.err.println(e.getMessage());
							row8 = null;

						}

						/**
						 * [tFileInputDelimited_8 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_8 main ] start
						 */

						currentComponent = "tFileInputDelimited_8";

						tos_count_tFileInputDelimited_8++;

						/**
						 * [tFileInputDelimited_8 main ] stop
						 */

						/**
						 * [tFileInputDelimited_8 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_8";

						/**
						 * [tFileInputDelimited_8 process_data_begin ] stop
						 */
// Start of branch "row8"
						if (row8 != null) {

							/**
							 * [tMap_8 main ] start
							 */

							currentComponent = "tMap_8";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row8"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_8 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_8 = false;
							boolean mainRowRejected_tMap_8 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_8__Struct Var = Var__tMap_8;// ###############################
								// ###############################
								// # Output tables

								channel = null;

// # Output table : 'channel'
								channel_tmp.id_channel = 0;
								channel_tmp.distribution_channel = row8.distribution_channel;
								channel_tmp.market_segment = row8.market_segment;
								channel = channel_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_8 = false;

							tos_count_tMap_8++;

							/**
							 * [tMap_8 main ] stop
							 */

							/**
							 * [tMap_8 process_data_begin ] start
							 */

							currentComponent = "tMap_8";

							/**
							 * [tMap_8 process_data_begin ] stop
							 */
// Start of branch "channel"
							if (channel != null) {

								/**
								 * [tDBOutput_8 main ] start
								 */

								currentComponent = "tDBOutput_8";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "channel"

									);
								}

								whetherReject_tDBOutput_8 = false;
								pstmt_tDBOutput_8.setInt(1, channel.id_channel);

								if (channel.distribution_channel == null) {
									pstmt_tDBOutput_8.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_8.setString(2, channel.distribution_channel);
								}

								if (channel.market_segment == null) {
									pstmt_tDBOutput_8.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_8.setString(3, channel.market_segment);
								}

								pstmt_tDBOutput_8.addBatch();
								nb_line_tDBOutput_8++;

								batchSizeCounter_tDBOutput_8++;
								if (batchSize_tDBOutput_8 <= batchSizeCounter_tDBOutput_8) {
									try {
										int countSum_tDBOutput_8 = 0;
										for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
											countSum_tDBOutput_8 += (countEach_tDBOutput_8 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
										insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_8 = 0;
										for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
											countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0
													: countEach_tDBOutput_8);
										}
										rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
										insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_8 = 0;
								}
								commitCounter_tDBOutput_8++;

								if (commitEvery_tDBOutput_8 <= commitCounter_tDBOutput_8) {

									try {
										int countSum_tDBOutput_8 = 0;
										for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
											countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
										insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_8_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_8 = 0;
										for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
											countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0
													: countEach_tDBOutput_8);
										}
										rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
										insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_8 != 0) {
									}
									conn_tDBOutput_8.commit();
									if (rowsToCommitCount_tDBOutput_8 != 0) {
										rowsToCommitCount_tDBOutput_8 = 0;
									}
									commitCounter_tDBOutput_8 = 0;

								}

								tos_count_tDBOutput_8++;

								/**
								 * [tDBOutput_8 main ] stop
								 */

								/**
								 * [tDBOutput_8 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_8";

								/**
								 * [tDBOutput_8 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_8 process_data_end ] start
								 */

								currentComponent = "tDBOutput_8";

								/**
								 * [tDBOutput_8 process_data_end ] stop
								 */

							} // End of branch "channel"

							/**
							 * [tMap_8 process_data_end ] start
							 */

							currentComponent = "tMap_8";

							/**
							 * [tMap_8 process_data_end ] stop
							 */

						} // End of branch "row8"

						/**
						 * [tFileInputDelimited_8 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_8";

						/**
						 * [tFileInputDelimited_8 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_8 end ] start
						 */

						currentComponent = "tFileInputDelimited_8";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_8 != null) {
							fid_tFileInputDelimited_8.close();
						}
					}
					if (fid_tFileInputDelimited_8 != null) {
						globalMap.put("tFileInputDelimited_8_NB_LINE", fid_tFileInputDelimited_8.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_8", true);
				end_Hash.put("tFileInputDelimited_8", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_8 end ] stop
				 */

				/**
				 * [tMap_8 end ] start
				 */

				currentComponent = "tMap_8";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row8");
				}

				ok_Hash.put("tMap_8", true);
				end_Hash.put("tMap_8", System.currentTimeMillis());

				/**
				 * [tMap_8 end ] stop
				 */

				/**
				 * [tDBOutput_8 end ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					if (batchSizeCounter_tDBOutput_8 != 0) {
						int countSum_tDBOutput_8 = 0;

						for (int countEach_tDBOutput_8 : pstmt_tDBOutput_8.executeBatch()) {
							countSum_tDBOutput_8 += (countEach_tDBOutput_8 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

						insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_8 = 0;
					for (int countEach_tDBOutput_8 : e.getUpdateCounts()) {
						countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
					}
					rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;

					insertedCount_tDBOutput_8 += countSum_tDBOutput_8;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_8 = 0;

				if (pstmt_tDBOutput_8 != null) {

					pstmt_tDBOutput_8.close();
					resourceMap.remove("pstmt_tDBOutput_8");

				}
				resourceMap.put("statementClosed_tDBOutput_8", true);
				if (commitCounter_tDBOutput_8 > 0 && rowsToCommitCount_tDBOutput_8 != 0) {

				}
				conn_tDBOutput_8.commit();
				if (commitCounter_tDBOutput_8 > 0 && rowsToCommitCount_tDBOutput_8 != 0) {

					rowsToCommitCount_tDBOutput_8 = 0;
				}
				commitCounter_tDBOutput_8 = 0;

				conn_tDBOutput_8.close();

				resourceMap.put("finish_tDBOutput_8", true);

				nb_line_deleted_tDBOutput_8 = nb_line_deleted_tDBOutput_8 + deletedCount_tDBOutput_8;
				nb_line_update_tDBOutput_8 = nb_line_update_tDBOutput_8 + updatedCount_tDBOutput_8;
				nb_line_inserted_tDBOutput_8 = nb_line_inserted_tDBOutput_8 + insertedCount_tDBOutput_8;
				nb_line_rejected_tDBOutput_8 = nb_line_rejected_tDBOutput_8 + rejectedCount_tDBOutput_8;

				globalMap.put("tDBOutput_8_NB_LINE", nb_line_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_UPDATED", nb_line_update_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_DELETED", nb_line_deleted_tDBOutput_8);
				globalMap.put("tDBOutput_8_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_8);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "channel");
				}

				ok_Hash.put("tDBOutput_8", true);
				end_Hash.put("tDBOutput_8", System.currentTimeMillis());

				/**
				 * [tDBOutput_8 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_8 finally ] start
				 */

				currentComponent = "tFileInputDelimited_8";

				/**
				 * [tFileInputDelimited_8 finally ] stop
				 */

				/**
				 * [tMap_8 finally ] start
				 */

				currentComponent = "tMap_8";

				/**
				 * [tMap_8 finally ] stop
				 */

				/**
				 * [tDBOutput_8 finally ] start
				 */

				currentComponent = "tDBOutput_8";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_8") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_8 = null;
						if ((pstmtToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_8")) != null) {
							pstmtToClose_tDBOutput_8.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_8") == null) {
						java.sql.Connection ctn_tDBOutput_8 = null;
						if ((ctn_tDBOutput_8 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_8")) != null) {
							try {
								ctn_tDBOutput_8.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_8) {
								String errorMessage_tDBOutput_8 = "failed to close the connection in tDBOutput_8 :"
										+ sqlEx_tDBOutput_8.getMessage();
								System.err.println(errorMessage_tDBOutput_8);
							}
						}
					}
				}

				/**
				 * [tDBOutput_8 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_8_SUBPROCESS_STATE", 1);
	}

	public static class timeStruct implements routines.system.IPersistableRow<timeStruct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_date;

		public int getId_date() {
			return this.id_date;
		}

		public Integer day_num;

		public Integer getDay_num() {
			return this.day_num;
		}

		public Integer month_num;

		public Integer getMonth_num() {
			return this.month_num;
		}

		public String month_name;

		public String getMonth_name() {
			return this.month_name;
		}

		public Integer year_num;

		public Integer getYear_num() {
			return this.year_num;
		}

		public Integer week_number;

		public Integer getWeek_number() {
			return this.week_number;
		}

		public Integer day_of_month;

		public Integer getDay_of_month() {
			return this.day_of_month;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_date;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final timeStruct other = (timeStruct) obj;

			if (this.id_date != other.id_date)
				return false;

			return true;
		}

		public void copyDataTo(timeStruct other) {

			other.id_date = this.id_date;
			other.day_num = this.day_num;
			other.month_num = this.month_num;
			other.month_name = this.month_name;
			other.year_num = this.year_num;
			other.week_number = this.week_number;
			other.day_of_month = this.day_of_month;

		}

		public void copyKeysDataTo(timeStruct other) {

			other.id_date = this.id_date;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_date = dis.readInt();

					this.day_num = readInteger(dis);

					this.month_num = readInteger(dis);

					this.month_name = readString(dis);

					this.year_num = readInteger(dis);

					this.week_number = readInteger(dis);

					this.day_of_month = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.id_date = dis.readInt();

					this.day_num = readInteger(dis);

					this.month_num = readInteger(dis);

					this.month_name = readString(dis);

					this.year_num = readInteger(dis);

					this.week_number = readInteger(dis);

					this.day_of_month = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_date);

				// Integer

				writeInteger(this.day_num, dos);

				// Integer

				writeInteger(this.month_num, dos);

				// String

				writeString(this.month_name, dos);

				// Integer

				writeInteger(this.year_num, dos);

				// Integer

				writeInteger(this.week_number, dos);

				// Integer

				writeInteger(this.day_of_month, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_date);

				// Integer

				writeInteger(this.day_num, dos);

				// Integer

				writeInteger(this.month_num, dos);

				// String

				writeString(this.month_name, dos);

				// Integer

				writeInteger(this.year_num, dos);

				// Integer

				writeInteger(this.week_number, dos);

				// Integer

				writeInteger(this.day_of_month, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_date=" + String.valueOf(id_date));
			sb.append(",day_num=" + String.valueOf(day_num));
			sb.append(",month_num=" + String.valueOf(month_num));
			sb.append(",month_name=" + month_name);
			sb.append(",year_num=" + String.valueOf(year_num));
			sb.append(",week_number=" + String.valueOf(week_number));
			sb.append(",day_of_month=" + String.valueOf(day_of_month));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(timeStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_date, other.id_date);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_FINAL_DW_dim = new byte[0];
		static byte[] commonByteArray_FINAL_DW_dim = new byte[0];

		public String hotel;

		public String getHotel() {
			return this.hotel;
		}

		public Integer is_canceled;

		public Integer getIs_canceled() {
			return this.is_canceled;
		}

		public Integer lead_time;

		public Integer getLead_time() {
			return this.lead_time;
		}

		public Integer arrival_date_year;

		public Integer getArrival_date_year() {
			return this.arrival_date_year;
		}

		public String arrival_date_month;

		public String getArrival_date_month() {
			return this.arrival_date_month;
		}

		public Integer arrival_date_week_number;

		public Integer getArrival_date_week_number() {
			return this.arrival_date_week_number;
		}

		public Integer arrival_date_day_of_month;

		public Integer getArrival_date_day_of_month() {
			return this.arrival_date_day_of_month;
		}

		public Integer stays_in_weekend_nights;

		public Integer getStays_in_weekend_nights() {
			return this.stays_in_weekend_nights;
		}

		public Integer stays_in_week_nights;

		public Integer getStays_in_week_nights() {
			return this.stays_in_week_nights;
		}

		public Integer adults;

		public Integer getAdults() {
			return this.adults;
		}

		public Integer children;

		public Integer getChildren() {
			return this.children;
		}

		public Integer babies;

		public Integer getBabies() {
			return this.babies;
		}

		public String meal;

		public String getMeal() {
			return this.meal;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String market_segment;

		public String getMarket_segment() {
			return this.market_segment;
		}

		public String distribution_channel;

		public String getDistribution_channel() {
			return this.distribution_channel;
		}

		public Integer is_repeated_guest;

		public Integer getIs_repeated_guest() {
			return this.is_repeated_guest;
		}

		public Integer previous_cancellations;

		public Integer getPrevious_cancellations() {
			return this.previous_cancellations;
		}

		public Integer previous_bookings_not_canceled;

		public Integer getPrevious_bookings_not_canceled() {
			return this.previous_bookings_not_canceled;
		}

		public Character reserved_room_type;

		public Character getReserved_room_type() {
			return this.reserved_room_type;
		}

		public Character assigned_room_type;

		public Character getAssigned_room_type() {
			return this.assigned_room_type;
		}

		public Integer booking_changes;

		public Integer getBooking_changes() {
			return this.booking_changes;
		}

		public String deposit_type;

		public String getDeposit_type() {
			return this.deposit_type;
		}

		public String agent;

		public String getAgent() {
			return this.agent;
		}

		public String company;

		public String getCompany() {
			return this.company;
		}

		public Integer days_in_waiting_list;

		public Integer getDays_in_waiting_list() {
			return this.days_in_waiting_list;
		}

		public String customer_type;

		public String getCustomer_type() {
			return this.customer_type;
		}

		public Float adr;

		public Float getAdr() {
			return this.adr;
		}

		public Integer required_car_parking_spaces;

		public Integer getRequired_car_parking_spaces() {
			return this.required_car_parking_spaces;
		}

		public Integer total_of_special_requests;

		public Integer getTotal_of_special_requests() {
			return this.total_of_special_requests;
		}

		public String reservation_status;

		public String getReservation_status() {
			return this.reservation_status;
		}

		public java.util.Date reservation_status_date;

		public java.util.Date getReservation_status_date() {
			return this.reservation_status_date;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_FINAL_DW_dim.length) {
					if (length < 1024 && commonByteArray_FINAL_DW_dim.length == 0) {
						commonByteArray_FINAL_DW_dim = new byte[1024];
					} else {
						commonByteArray_FINAL_DW_dim = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_FINAL_DW_dim, 0, length);
				strReturn = new String(commonByteArray_FINAL_DW_dim, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_FINAL_DW_dim) {

				try {

					int length = 0;

					this.hotel = readString(dis);

					this.is_canceled = readInteger(dis);

					this.lead_time = readInteger(dis);

					this.arrival_date_year = readInteger(dis);

					this.arrival_date_month = readString(dis);

					this.arrival_date_week_number = readInteger(dis);

					this.arrival_date_day_of_month = readInteger(dis);

					this.stays_in_weekend_nights = readInteger(dis);

					this.stays_in_week_nights = readInteger(dis);

					this.adults = readInteger(dis);

					this.children = readInteger(dis);

					this.babies = readInteger(dis);

					this.meal = readString(dis);

					this.country = readString(dis);

					this.market_segment = readString(dis);

					this.distribution_channel = readString(dis);

					this.is_repeated_guest = readInteger(dis);

					this.previous_cancellations = readInteger(dis);

					this.previous_bookings_not_canceled = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.reserved_room_type = null;
					} else {
						this.reserved_room_type = dis.readChar();
					}

					length = dis.readByte();
					if (length == -1) {
						this.assigned_room_type = null;
					} else {
						this.assigned_room_type = dis.readChar();
					}

					this.booking_changes = readInteger(dis);

					this.deposit_type = readString(dis);

					this.agent = readString(dis);

					this.company = readString(dis);

					this.days_in_waiting_list = readInteger(dis);

					this.customer_type = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.adr = null;
					} else {
						this.adr = dis.readFloat();
					}

					this.required_car_parking_spaces = readInteger(dis);

					this.total_of_special_requests = readInteger(dis);

					this.reservation_status = readString(dis);

					this.reservation_status_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.hotel, dos);

				// Integer

				writeInteger(this.is_canceled, dos);

				// Integer

				writeInteger(this.lead_time, dos);

				// Integer

				writeInteger(this.arrival_date_year, dos);

				// String

				writeString(this.arrival_date_month, dos);

				// Integer

				writeInteger(this.arrival_date_week_number, dos);

				// Integer

				writeInteger(this.arrival_date_day_of_month, dos);

				// Integer

				writeInteger(this.stays_in_weekend_nights, dos);

				// Integer

				writeInteger(this.stays_in_week_nights, dos);

				// Integer

				writeInteger(this.adults, dos);

				// Integer

				writeInteger(this.children, dos);

				// Integer

				writeInteger(this.babies, dos);

				// String

				writeString(this.meal, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.market_segment, dos);

				// String

				writeString(this.distribution_channel, dos);

				// Integer

				writeInteger(this.is_repeated_guest, dos);

				// Integer

				writeInteger(this.previous_cancellations, dos);

				// Integer

				writeInteger(this.previous_bookings_not_canceled, dos);

				// Character

				if (this.reserved_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.reserved_room_type);
				}

				// Character

				if (this.assigned_room_type == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.assigned_room_type);
				}

				// Integer

				writeInteger(this.booking_changes, dos);

				// String

				writeString(this.deposit_type, dos);

				// String

				writeString(this.agent, dos);

				// String

				writeString(this.company, dos);

				// Integer

				writeInteger(this.days_in_waiting_list, dos);

				// String

				writeString(this.customer_type, dos);

				// Float

				if (this.adr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.adr);
				}

				// Integer

				writeInteger(this.required_car_parking_spaces, dos);

				// Integer

				writeInteger(this.total_of_special_requests, dos);

				// String

				writeString(this.reservation_status, dos);

				// java.util.Date

				writeDate(this.reservation_status_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("hotel=" + hotel);
			sb.append(",is_canceled=" + String.valueOf(is_canceled));
			sb.append(",lead_time=" + String.valueOf(lead_time));
			sb.append(",arrival_date_year=" + String.valueOf(arrival_date_year));
			sb.append(",arrival_date_month=" + arrival_date_month);
			sb.append(",arrival_date_week_number=" + String.valueOf(arrival_date_week_number));
			sb.append(",arrival_date_day_of_month=" + String.valueOf(arrival_date_day_of_month));
			sb.append(",stays_in_weekend_nights=" + String.valueOf(stays_in_weekend_nights));
			sb.append(",stays_in_week_nights=" + String.valueOf(stays_in_week_nights));
			sb.append(",adults=" + String.valueOf(adults));
			sb.append(",children=" + String.valueOf(children));
			sb.append(",babies=" + String.valueOf(babies));
			sb.append(",meal=" + meal);
			sb.append(",country=" + country);
			sb.append(",market_segment=" + market_segment);
			sb.append(",distribution_channel=" + distribution_channel);
			sb.append(",is_repeated_guest=" + String.valueOf(is_repeated_guest));
			sb.append(",previous_cancellations=" + String.valueOf(previous_cancellations));
			sb.append(",previous_bookings_not_canceled=" + String.valueOf(previous_bookings_not_canceled));
			sb.append(",reserved_room_type=" + String.valueOf(reserved_room_type));
			sb.append(",assigned_room_type=" + String.valueOf(assigned_room_type));
			sb.append(",booking_changes=" + String.valueOf(booking_changes));
			sb.append(",deposit_type=" + deposit_type);
			sb.append(",agent=" + agent);
			sb.append(",company=" + company);
			sb.append(",days_in_waiting_list=" + String.valueOf(days_in_waiting_list));
			sb.append(",customer_type=" + customer_type);
			sb.append(",adr=" + String.valueOf(adr));
			sb.append(",required_car_parking_spaces=" + String.valueOf(required_car_parking_spaces));
			sb.append(",total_of_special_requests=" + String.valueOf(total_of_special_requests));
			sb.append(",reservation_status=" + reservation_status);
			sb.append(",reservation_status_date=" + String.valueOf(reservation_status_date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_9_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row9Struct row9 = new row9Struct();
				timeStruct time = new timeStruct();

				/**
				 * [tDBOutput_9 begin ] start
				 */

				ok_Hash.put("tDBOutput_9", false);
				start_Hash.put("tDBOutput_9", System.currentTimeMillis());

				currentComponent = "tDBOutput_9";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "time");
				}

				int tos_count_tDBOutput_9 = 0;

				int nb_line_tDBOutput_9 = 0;
				int nb_line_update_tDBOutput_9 = 0;
				int nb_line_inserted_tDBOutput_9 = 0;
				int nb_line_deleted_tDBOutput_9 = 0;
				int nb_line_rejected_tDBOutput_9 = 0;

				int deletedCount_tDBOutput_9 = 0;
				int updatedCount_tDBOutput_9 = 0;
				int insertedCount_tDBOutput_9 = 0;
				int rowsToCommitCount_tDBOutput_9 = 0;
				int rejectedCount_tDBOutput_9 = 0;

				String tableName_tDBOutput_9 = "dim_time";
				boolean whetherReject_tDBOutput_9 = false;

				java.util.Calendar calendar_tDBOutput_9 = java.util.Calendar.getInstance();
				calendar_tDBOutput_9.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_9 = calendar_tDBOutput_9.getTime().getTime();
				calendar_tDBOutput_9.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_9 = calendar_tDBOutput_9.getTime().getTime();
				long date_tDBOutput_9;

				java.sql.Connection conn_tDBOutput_9 = null;

				String properties_tDBOutput_9 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_9 == null || properties_tDBOutput_9.trim().length() == 0) {
					properties_tDBOutput_9 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_9.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_9 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_9.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_9 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_9 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dw_final" + "?"
						+ properties_tDBOutput_9;

				String driverClass_tDBOutput_9 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_9 = "root";

				final String decryptedPassword_tDBOutput_9 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:Dydd/np1pK38CXZh6XL8sBEnLZ7hMnKQKBUNkw==");

				String dbPwd_tDBOutput_9 = decryptedPassword_tDBOutput_9;
				java.lang.Class.forName(driverClass_tDBOutput_9);

				conn_tDBOutput_9 = java.sql.DriverManager.getConnection(url_tDBOutput_9, dbUser_tDBOutput_9,
						dbPwd_tDBOutput_9);

				resourceMap.put("conn_tDBOutput_9", conn_tDBOutput_9);
				conn_tDBOutput_9.setAutoCommit(false);
				int commitEvery_tDBOutput_9 = 10000;
				int commitCounter_tDBOutput_9 = 0;

				int count_tDBOutput_9 = 0;

				String insert_tDBOutput_9 = "INSERT INTO `" + "dim_time"
						+ "` (`id_date`,`day_num`,`month_num`,`month_name`,`year_num`,`week_number`,`day_of_month`) VALUES (?,?,?,?,?,?,?)";
				int batchSize_tDBOutput_9 = 100;
				int batchSizeCounter_tDBOutput_9 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(insert_tDBOutput_9);
				resourceMap.put("pstmt_tDBOutput_9", pstmt_tDBOutput_9);

				/**
				 * [tDBOutput_9 begin ] stop
				 */

				/**
				 * [tMap_9 begin ] start
				 */

				ok_Hash.put("tMap_9", false);
				start_Hash.put("tMap_9", System.currentTimeMillis());

				currentComponent = "tMap_9";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row9");
				}

				int tos_count_tMap_9 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_9__Struct {
				}
				Var__tMap_9__Struct Var__tMap_9 = new Var__tMap_9__Struct();
// ###############################

// ###############################
// # Outputs initialization
				timeStruct time_tmp = new timeStruct();
// ###############################

				/**
				 * [tMap_9 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_9 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_9", false);
				start_Hash.put("tFileInputDelimited_9", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_9";

				int tos_count_tFileInputDelimited_9 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_9 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_9 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_9 = null;
				int limit_tFileInputDelimited_9 = -1;
				try {

					Object filename_tFileInputDelimited_9 = "C:/Users/Naffati/Downloads/hotel_bookings.csv";
					if (filename_tFileInputDelimited_9 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_9 = 0, random_value_tFileInputDelimited_9 = -1;
						if (footer_value_tFileInputDelimited_9 > 0 || random_value_tFileInputDelimited_9 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_9 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Naffati/Downloads/hotel_bookings.csv", "US-ASCII", ",", "\n", false, 1, 0,
								limit_tFileInputDelimited_9, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_9 != null && fid_tFileInputDelimited_9.nextRecord()) {
						rowstate_tFileInputDelimited_9.reset();

						row9 = null;

						boolean whetherReject_tFileInputDelimited_9 = false;
						row9 = new row9Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_9 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_9 = 0;

							row9.hotel = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 1;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.is_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_canceled", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.is_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 2;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.lead_time = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"lead_time", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.lead_time = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 3;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.arrival_date_year = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_year", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.arrival_date_year = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 4;

							row9.arrival_date_month = fid_tFileInputDelimited_9
									.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 5;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.arrival_date_week_number = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_week_number", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.arrival_date_week_number = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 6;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.arrival_date_day_of_month = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"arrival_date_day_of_month", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.arrival_date_day_of_month = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 7;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.stays_in_weekend_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_weekend_nights", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.stays_in_weekend_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 8;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.stays_in_week_nights = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stays_in_week_nights", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.stays_in_week_nights = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 9;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.adults = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adults", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.adults = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 10;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.children = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"children", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.children = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 11;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.babies = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"babies", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.babies = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 12;

							row9.meal = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 13;

							row9.country = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 14;

							row9.market_segment = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 15;

							row9.distribution_channel = fid_tFileInputDelimited_9
									.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 16;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.is_repeated_guest = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"is_repeated_guest", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.is_repeated_guest = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 17;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.previous_cancellations = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_cancellations", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.previous_cancellations = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 18;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.previous_bookings_not_canceled = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"previous_bookings_not_canceled", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.previous_bookings_not_canceled = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 19;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.reserved_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reserved_room_type", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.reserved_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 20;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.assigned_room_type = ParserUtils.parseTo_Character(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"assigned_room_type", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.assigned_room_type = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 21;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.booking_changes = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"booking_changes", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.booking_changes = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 22;

							row9.deposit_type = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 23;

							row9.agent = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 24;

							row9.company = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 25;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.days_in_waiting_list = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"days_in_waiting_list", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.days_in_waiting_list = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 26;

							row9.customer_type = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 27;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.adr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"adr", "row9", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}

							} else {

								row9.adr = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 28;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.required_car_parking_spaces = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"required_car_parking_spaces", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.required_car_parking_spaces = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 29;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.total_of_special_requests = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"total_of_special_requests", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.total_of_special_requests = null;

							}

							columnIndexWithD_tFileInputDelimited_9 = 30;

							row9.reservation_status = fid_tFileInputDelimited_9
									.get(columnIndexWithD_tFileInputDelimited_9);

							columnIndexWithD_tFileInputDelimited_9 = 31;

							temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
							if (temp.length() > 0) {

								try {

									row9.reservation_status_date = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");

								} catch (java.lang.Exception ex_tFileInputDelimited_9) {
									globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",
											ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"reservation_status_date", "row9", temp, ex_tFileInputDelimited_9),
											ex_tFileInputDelimited_9));
								}

							} else {

								row9.reservation_status_date = null;

							}

							if (rowstate_tFileInputDelimited_9.getException() != null) {
								throw rowstate_tFileInputDelimited_9.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_9 = true;

							System.err.println(e.getMessage());
							row9 = null;

						}

						/**
						 * [tFileInputDelimited_9 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_9 main ] start
						 */

						currentComponent = "tFileInputDelimited_9";

						tos_count_tFileInputDelimited_9++;

						/**
						 * [tFileInputDelimited_9 main ] stop
						 */

						/**
						 * [tFileInputDelimited_9 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_9";

						/**
						 * [tFileInputDelimited_9 process_data_begin ] stop
						 */
// Start of branch "row9"
						if (row9 != null) {

							/**
							 * [tMap_9 main ] start
							 */

							currentComponent = "tMap_9";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row9"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_9 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_9 = false;
							boolean mainRowRejected_tMap_9 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_9__Struct Var = Var__tMap_9;// ###############################
								// ###############################
								// # Output tables

								time = null;

// # Output table : 'time'
								time_tmp.id_date = 0;
								time_tmp.day_num = null;
								time_tmp.month_num = null;
								time_tmp.month_name = row9.arrival_date_month;
								time_tmp.year_num = row9.arrival_date_year;
								time_tmp.week_number = row9.arrival_date_week_number;
								time_tmp.day_of_month = row9.arrival_date_day_of_month;
								time = time_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_9 = false;

							tos_count_tMap_9++;

							/**
							 * [tMap_9 main ] stop
							 */

							/**
							 * [tMap_9 process_data_begin ] start
							 */

							currentComponent = "tMap_9";

							/**
							 * [tMap_9 process_data_begin ] stop
							 */
// Start of branch "time"
							if (time != null) {

								/**
								 * [tDBOutput_9 main ] start
								 */

								currentComponent = "tDBOutput_9";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "time"

									);
								}

								whetherReject_tDBOutput_9 = false;
								pstmt_tDBOutput_9.setInt(1, time.id_date);

								if (time.day_num == null) {
									pstmt_tDBOutput_9.setNull(2, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_9.setInt(2, time.day_num);
								}

								if (time.month_num == null) {
									pstmt_tDBOutput_9.setNull(3, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_9.setInt(3, time.month_num);
								}

								if (time.month_name == null) {
									pstmt_tDBOutput_9.setNull(4, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_9.setString(4, time.month_name);
								}

								if (time.year_num == null) {
									pstmt_tDBOutput_9.setNull(5, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_9.setInt(5, time.year_num);
								}

								if (time.week_number == null) {
									pstmt_tDBOutput_9.setNull(6, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_9.setInt(6, time.week_number);
								}

								if (time.day_of_month == null) {
									pstmt_tDBOutput_9.setNull(7, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_9.setInt(7, time.day_of_month);
								}

								pstmt_tDBOutput_9.addBatch();
								nb_line_tDBOutput_9++;

								batchSizeCounter_tDBOutput_9++;
								if (batchSize_tDBOutput_9 <= batchSizeCounter_tDBOutput_9) {
									try {
										int countSum_tDBOutput_9 = 0;
										for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
											countSum_tDBOutput_9 += (countEach_tDBOutput_9 == java.sql.Statement.EXECUTE_FAILED
													? 0
													: 1);
										}
										rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
										insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_9 = 0;
										for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
											countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0
													: countEach_tDBOutput_9);
										}
										rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
										insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_9 = 0;
								}
								commitCounter_tDBOutput_9++;

								if (commitEvery_tDBOutput_9 <= commitCounter_tDBOutput_9) {

									try {
										int countSum_tDBOutput_9 = 0;
										for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
											countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : 1);
										}
										rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
										insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_9_ERROR_MESSAGE", e.getMessage());
										int countSum_tDBOutput_9 = 0;
										for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
											countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0
													: countEach_tDBOutput_9);
										}
										rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
										insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
										System.err.println(e.getMessage());

									}
									if (rowsToCommitCount_tDBOutput_9 != 0) {
									}
									conn_tDBOutput_9.commit();
									if (rowsToCommitCount_tDBOutput_9 != 0) {
										rowsToCommitCount_tDBOutput_9 = 0;
									}
									commitCounter_tDBOutput_9 = 0;

								}

								tos_count_tDBOutput_9++;

								/**
								 * [tDBOutput_9 main ] stop
								 */

								/**
								 * [tDBOutput_9 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_9";

								/**
								 * [tDBOutput_9 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_9 process_data_end ] start
								 */

								currentComponent = "tDBOutput_9";

								/**
								 * [tDBOutput_9 process_data_end ] stop
								 */

							} // End of branch "time"

							/**
							 * [tMap_9 process_data_end ] start
							 */

							currentComponent = "tMap_9";

							/**
							 * [tMap_9 process_data_end ] stop
							 */

						} // End of branch "row9"

						/**
						 * [tFileInputDelimited_9 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_9";

						/**
						 * [tFileInputDelimited_9 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_9 end ] start
						 */

						currentComponent = "tFileInputDelimited_9";

					}
				} finally {
					if (!((Object) ("C:/Users/Naffati/Downloads/hotel_bookings.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_9 != null) {
							fid_tFileInputDelimited_9.close();
						}
					}
					if (fid_tFileInputDelimited_9 != null) {
						globalMap.put("tFileInputDelimited_9_NB_LINE", fid_tFileInputDelimited_9.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_9", true);
				end_Hash.put("tFileInputDelimited_9", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_9 end ] stop
				 */

				/**
				 * [tMap_9 end ] start
				 */

				currentComponent = "tMap_9";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row9");
				}

				ok_Hash.put("tMap_9", true);
				end_Hash.put("tMap_9", System.currentTimeMillis());

				/**
				 * [tMap_9 end ] stop
				 */

				/**
				 * [tDBOutput_9 end ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					if (batchSizeCounter_tDBOutput_9 != 0) {
						int countSum_tDBOutput_9 = 0;

						for (int countEach_tDBOutput_9 : pstmt_tDBOutput_9.executeBatch()) {
							countSum_tDBOutput_9 += (countEach_tDBOutput_9 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

						insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

					}

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_9 = 0;
					for (int countEach_tDBOutput_9 : e.getUpdateCounts()) {
						countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
					}
					rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;

					insertedCount_tDBOutput_9 += countSum_tDBOutput_9;

					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_9 = 0;

				if (pstmt_tDBOutput_9 != null) {

					pstmt_tDBOutput_9.close();
					resourceMap.remove("pstmt_tDBOutput_9");

				}
				resourceMap.put("statementClosed_tDBOutput_9", true);
				if (commitCounter_tDBOutput_9 > 0 && rowsToCommitCount_tDBOutput_9 != 0) {

				}
				conn_tDBOutput_9.commit();
				if (commitCounter_tDBOutput_9 > 0 && rowsToCommitCount_tDBOutput_9 != 0) {

					rowsToCommitCount_tDBOutput_9 = 0;
				}
				commitCounter_tDBOutput_9 = 0;

				conn_tDBOutput_9.close();

				resourceMap.put("finish_tDBOutput_9", true);

				nb_line_deleted_tDBOutput_9 = nb_line_deleted_tDBOutput_9 + deletedCount_tDBOutput_9;
				nb_line_update_tDBOutput_9 = nb_line_update_tDBOutput_9 + updatedCount_tDBOutput_9;
				nb_line_inserted_tDBOutput_9 = nb_line_inserted_tDBOutput_9 + insertedCount_tDBOutput_9;
				nb_line_rejected_tDBOutput_9 = nb_line_rejected_tDBOutput_9 + rejectedCount_tDBOutput_9;

				globalMap.put("tDBOutput_9_NB_LINE", nb_line_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_UPDATED", nb_line_update_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_DELETED", nb_line_deleted_tDBOutput_9);
				globalMap.put("tDBOutput_9_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_9);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "time");
				}

				ok_Hash.put("tDBOutput_9", true);
				end_Hash.put("tDBOutput_9", System.currentTimeMillis());

				/**
				 * [tDBOutput_9 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_9 finally ] start
				 */

				currentComponent = "tFileInputDelimited_9";

				/**
				 * [tFileInputDelimited_9 finally ] stop
				 */

				/**
				 * [tMap_9 finally ] start
				 */

				currentComponent = "tMap_9";

				/**
				 * [tMap_9 finally ] stop
				 */

				/**
				 * [tDBOutput_9 finally ] start
				 */

				currentComponent = "tDBOutput_9";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_9") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_9 = null;
						if ((pstmtToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_9")) != null) {
							pstmtToClose_tDBOutput_9.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_9") == null) {
						java.sql.Connection ctn_tDBOutput_9 = null;
						if ((ctn_tDBOutput_9 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_9")) != null) {
							try {
								ctn_tDBOutput_9.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_9) {
								String errorMessage_tDBOutput_9 = "failed to close the connection in tDBOutput_9 :"
										+ sqlEx_tDBOutput_9.getMessage();
								System.err.println(errorMessage_tDBOutput_9);
							}
						}
					}
				}

				/**
				 * [tDBOutput_9 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_9_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final dim dimClass = new dim();

		int exitCode = dimClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = dim.class.getClassLoader()
					.getResourceAsStream("final_dw/dim_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = dim.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_2) {
			globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_2.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_3Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_3) {
			globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_3.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_4Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_4) {
			globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_4.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_5Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_5) {
			globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_5.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_6Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_6) {
			globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_6.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_7Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_7) {
			globalMap.put("tFileInputDelimited_7_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_7.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_8Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_8) {
			globalMap.put("tFileInputDelimited_8_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_8.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_9Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_9) {
			globalMap.put("tFileInputDelimited_9_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_9.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : dim");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 676057 characters generated by Talend Open Studio for Data Integration on the
 * 29 mai 2025 à 3:19:18 PM CEST
 ************************************************************************************************/